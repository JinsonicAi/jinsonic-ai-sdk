"""Send one saved Command envelope (not a REST path). Never generates write keys."""
import argparse
import json
from pathlib import Path
from aibox_client import Client, CONTRACT, PREFIX, load_config, send_request


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("request_file")
    parser.add_argument("--config", default="config.json")
    parser.add_argument("--allow-write", action="store_true")
    parser.add_argument("--wait", action="store_true")
    args = parser.parse_args()
    raw = Path(args.request_file).read_text(encoding="utf-8")
    if "REPLACE_" in raw:
        raise ValueError("Replace the sample placeholders before sending")
    request = json.loads(raw)
    route = request["uri"].removeprefix(PREFIX)
    if route in CONTRACT["writes"] and not args.allow_write:
        raise ValueError("This changes device data; explicitly add --allow-write")
    client = Client(load_config(args.config))
    result = send_request(client, request)
    # Deliberately print only status/IDs. API results may contain camera credentials,
    # personal information or Ticket URLs. Access result programmatically instead.
    print("code=0", "operation_id=" + str(result.get("operation_id", "")), "result_fields=" + ",".join(result) if isinstance(result, dict) else "result=array")
    if args.wait and isinstance(result, dict) and result.get("operation_id"):
        client.wait_operation(result["operation_id"])
        print("operation succeeded")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        raise SystemExit(str(exc)) from None
