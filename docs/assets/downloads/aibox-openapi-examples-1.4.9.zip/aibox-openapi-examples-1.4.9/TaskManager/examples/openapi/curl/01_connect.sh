#!/usr/bin/env bash
# Requires Bash, curl and Python 3 (JSON handling). Real credentials never appear
# in curl arguments, stdout, source code or shell history. Do not run with bash -x.
set -euo pipefail
umask 077
script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
config="${1:-config.json}"
scratch="$(mktemp -d /tmp/aibox-api-curl.XXXXXX)"
trap 'rm -rf -- "$scratch"' EXIT
chmod 700 "$scratch"
python3 - "$script_dir/.." "$config" "$scratch" <<'PY'
import json, os, sys
from pathlib import Path
sys.path.insert(0, str(Path(sys.argv[1]) / 'python'))
from aibox_client import Client, load_config
c = load_config(sys.argv[2])
client = Client(c)  # Validate origin, credentials and trusted CA, no request yet.
p = Path(sys.argv[3])
def save(name, value):
    fd = os.open(p / name, os.O_WRONLY|os.O_CREAT|os.O_EXCL, 0o600)
    with os.fdopen(fd, 'w') as f: f.write(value)
def quoted(value):
    if any(ord(ch) < 32 for ch in value): raise ValueError('Invalid curl config value')
    return '"' + value.replace('\\', '\\\\').replace('"', '\\"') + '"'
save('curl.conf', 'url = ' + quoted(client.base_url + '/openapi/v1/command') + '\n' +
     ('cacert = ' + quoted(c['ca_file']) + '\n' if c.get('ca_file') else ''))
save('auth.json', json.dumps({'uri':'/openapi/v1/auth/token','request_id':'curl-auth','param':{'client_id':c['client_id'],'client_secret':c['client_secret']}}))
save('session.json', json.dumps({'uri':'/openapi/v1/session/get','request_id':'curl-session','param':{}}))
PY
request() {
  curl --silent --show-error --noproxy '*' --connect-timeout 5 --max-time 30 \
    --config "$scratch/curl.conf" -H 'Content-Type: application/json' \
    --data-binary "@$scratch/$1.json" --output "$scratch/response.json" --write-out '%{http_code}'
}
status="$(request auth)"
python3 - "$scratch" "$status" <<'PY'
import json, os, sys
from pathlib import Path
p = Path(sys.argv[1]); data = json.loads((p/'response.json').read_text())
if sys.argv[2] != '200' or data.get('code') != 0: raise SystemExit('Auth rejected; HTTP='+sys.argv[2]+' code='+str(data.get('code')))
result = data['result']; token = result['access_token']
if result.get('token_use') != 'openapi_client' or not token or any(not 33 <= ord(c) <= 126 or c in '"\\' for c in token): raise SystemExit('Invalid token response')
with (p/'curl.conf').open('a') as f: f.write('header = "X-Access-Token: '+token+'"\n')
print('1. Token acquired (not displayed)')
PY
status="$(request session)"
python3 - "$scratch/response.json" "$status" <<'PY'
import json, sys
data = json.load(open(sys.argv[1]))
if sys.argv[2] != '200' or data.get('code') != 0: raise SystemExit('Session rejected; HTTP='+sys.argv[2]+' code='+str(data.get('code')))
print('2. Session verified; scopes:', ', '.join(data['result']['scopes']))
PY
