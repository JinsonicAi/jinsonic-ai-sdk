# AIBox 客户开放 API：从首次连接到完整任务流程

适用：设备直连 OpenAPI v1；配套协议文档 1.4.9。Python、Node.js、curl 三种入口。
本示例是**客户服务端/BFF 的参考实现**，不是盒子内部插件 SDK，也不是网页私有接口示例。

先执行第 1～3 步。只读连接成功后，再执行任务示例。不要把本文任何“请求已成功”理解成“视频画面、模型效果、设备升级已经验收”。

## 交付内容

| 目标 | Python 3.10+（无需 pip） | Node.js 22.22+（无需 npm） |
|---|---|---|
| 首次鉴权、设备/节点目录/任务查询 | `python/01_connect.py` | `node/01-connect.mjs` |
| 创建、读取、完整修改、启动、确认结果、停止、删除 | `python/02_tasks.py` | `node/02-tasks.mjs` |
| HTTP 事件补偿、去重、SQLite 落库、游标恢复 | `python/03_events_poll.py` | 可通过相同 `events/*` URI 对接；持久化参考 Python |
| WSS 建连、ready、请求关联、心跳、订阅、按序补偿 | — | `node/03-events-wss.mjs`、`node/wss-channel.mjs` |
| 录像 Ticket + Range 下载 | `python/04_record_download.py` | `node/04-record-download.mjs` |
| 生成单接口请求文件 | `prepare_request.py` | `node/prepare-request.mjs` |
| 发送同一请求文件/重试同一幂等操作 | `python/call.py` | `node/call.mjs` |

另有 `curl/01_connect.sh`，以及覆盖协议 **65 个 URI** 的 `recipes.json`（包括只能由交付管理员调用的 5 个凭证管理接口）。每项附 `param`、Scope 和必要的风险说明。客户 SDK 明确拒绝凭证管理接口。

完整字段、错误码、能力边界见：

- [中文协议](../../docs/AIBOX_OPENAPI_INTEGRATION_PROTOCOL_ZH.md)
- [English protocol](../../docs/AIBOX_OPENAPI_INTEGRATION_PROTOCOL_EN.md)
- [交付和验收清单](DELIVERY-CHECKLIST.md)
- [已执行的验证及其边界](VALIDATION.md)

## 1. 先准备这四项，不能只给客户一个 IP

1. 设备 HTTPS 地址，例如 `https://box.customer.example:8099`。IP 访问也可以，但证书必须覆盖实际 IP。此地址只是 origin，**不要加 `/aibox/`、`/command` 或业务 URI**。
2. 设备网页登录用户名和密码，用于首次自助领取 `client_id/client_secret`；已有 Client 凭据可跳过领取。客户无需 SSH 或交付方代创建，也不使用网页私有接口。
3. 可信的设备证书链/CA 文件。由交付方通过可信渠道交付；不能遇到证书错误就加 `-k`、`verify=False` 或 `NODE_TLS_REJECT_UNAUTHORIZED=0`。只“信任 CA”还不够，证书 SAN 必须匹配设备地址。
4. 已安装兼容版本、已授权并加载完成的插件。做视频测试时，另外准备**盒子自身能访问**的 RTSP 源，而不仅是客户电脑能访问的源。

申请最小 Scope：

| 示例 | 所需 Scope |
|---|---|
| 首次连接 | `device.read task.read` |
| 创建/修改/删除新示例任务 | 加 `task.write` |
| 启停与媒体输出查询 | 再加 `task.execute media.read` |
| 持久化告警/任务/设备事件 | `device.read task.read alarm.read` |
| WSS 任务事件演示 | `task.read` |
| 录像下载 | `media.read` |

Scope 不自动继承。没有 `media.read`，即使能启动任务，也不能查询输出地址。
NAT/4G 场景通过已交付的 Gateway/VPN 接入；不要把 8099 直接开放到公网。本包不实现 Gateway 的租户协议。

### client_id 和 client_secret 从哪里来？

只增加这一步，后面的 Client Credentials、Token、任务等调用保持原样：

`网页登录用户名密码 → clients/bootstrap → client_id/client_secret → auth/token → 业务接口`

HTTP 仍发送到 `POST https://<设备地址>:8099/openapi/v1/command`，不带 Token；JSON 为：

```json
{
  "uri": "/openapi/v1/clients/bootstrap",
  "request_id": "每次领取生成并保存一个唯一请求ID",
  "param": {
    "username": "设备网页登录账号",
    "password": "设备网页登录原始密码",
    "display_name": "客户业务平台",
    "scopes": ["device.read", "task.read", "task.write", "task.execute", "media.read"]
  }
}
```

响应只在本次成功领取时包含 `result.client_id`、`result.client_secret`、`secret_returned_once: true`，**不会直接签发 Access Token**。

准备：复制 `bootstrap.example.json` 为 `bootstrap.json`，编辑设备地址、账号、CA 和最小 Scope；用编辑器将网页密码写入 `web-password.txt`，执行 `chmod 600 bootstrap.json web-password.txt`。不要把密码写到 shell 历史。密码文件只移除末尾一个换行，保留密码本身的空格。

任选一种领取（不要三种全部执行，每次新请求会创建独立 Client）：

```bash
python3 python/00_get_credentials.py --config bootstrap.json --output-dir issued-client
node node/00-get-credentials.mjs --config bootstrap.json --output-dir issued-client
bash curl/00_get_credentials.sh --config bootstrap.json --output-dir issued-client
```

三个入口都会在**全新的**私有目录 `issued-client/` 保存 `config.json`、`client-secret.txt` 和 `request-id.txt`，不覆盖已有文件，不打印密钥。curl 入口由 Python 处理 JSON，HTTP 请求由 curl 实际发送。之后直接运行：

```bash
python3 python/01_connect.py --config issued-client/config.json
# 或 node node/01-connect.mjs --config issued-client/config.json
# 或 bash curl/01_connect.sh issued-client/config.json
```

已经自动生成配置时，可跳过下面第 2 步的手动填写。正常业务进程只需保存 Client 凭据，不再需要网页密码。

**失效与重试规则：**

- 修改该网页账号密码后，通过该账号领取的旧 Client 凭据和派生 Token 全部失效；密码改回原值也不会恢复。账号删除/重建或权限改变同样失效。
- 用新密码重新领取，替换客户侧 Client 配置；已有 WSS 在后续收发/心跳时拒绝旧身份，需要重新换 Token、Ticket 并按持久化游标重连。已接受/正在执行的任务不会被改密自动撤销。
- 同一账号、同一 `request_id` 只签发一次。重试返回 `40901 / CLIENT_SECRET_ALREADY_ISSUED`，不再次展示 Secret；超时结果不明时不要自动换新 ID 循环重试。先联系设备管理员核查该请求记录，必要时轮换或撤销，再重新领取。
- 每账号当前凭据版本最多 16 个启用的自助 Client，设备累计最多 4096 条自助记录；达到上限明确报错，不无限增长。独立管理员原先创建的 Client 不随其他账号改密失效。
- `40101` 检查密码/重新领取；`40301` 检查权限；`42901` 按限流提示等待；`50301` 表示暂不可用，不能当成已鉴权。请求只用 HTTPS POST，禁止关闭证书校验。
- `clients/get/list` 永不返回原 Secret。原有管理员 `clients/create/update/rotate_secret` 功能和业务协议不变。

## 2. 配置一次，三种语言共用

在本 README 所在目录执行（Linux/macOS 示例；Windows 可在编辑器中复制文件）：

```bash
cp config.example.json config.json
```

用编辑器修改 `config.json`：

```json
{
  "base_url": "https://box.customer.example:8099",
  "client_id": "aibc_实际交付值",
  "client_secret_file": "client-secret.txt",
  "ca_file": "device-ca.pem",
  "timeout_seconds": 30,
  "operation_timeout_seconds": 90
}
```

把密钥单独放入 `client-secret.txt`，只写密钥本身，不加引号；把交付 CA 放入 `device-ca.pem`。所有文件路径相对 `config.json`，不是相对运行目录。

```bash
chmod 600 config.json client-secret.txt
```

证书已由操作系统/Node 默认信任时，可将 `ca_file` 设为 `""`。也可将 `client_secret_file` 设为 `""`，由服务管理器安全注入 `AIBOX_CLIENT_SECRET`，而不是把密钥粘贴进 shell 历史。不得把配置、密钥、Token 或客户数据提交 Git。

Node 的 HTTPS 请求会读取 `ca_file`。Node **内置 WebSocket** 的额外 CA 必须在进程启动前设置，使用与 `config.ca_file` 相同的绝对路径：

```bash
export NODE_EXTRA_CA_CERTS="$(pwd)/device-ca.pem"
```

PowerShell 对应：`$env:NODE_EXTRA_CA_CERTS = (Resolve-Path .\device-ca.pem).Path`。
本客户端直连设备，不继承通用 HTTP 代理配置；需要企业代理时由客户明确配置受信任出口，不要把设备凭据交给未知代理。

## 3. 第一次“创建连接”：先 HTTPS 鉴权

HTTPS 不需要创建 WebRTC 连接，也不需要等待网页 Wi-Fi 图标变绿。
每次业务请求都是 `POST /openapi/v1/command`，业务地址放在 JSON 的 `uri` 中。WSS 是第 6 步的可选长连接。

任选一种执行：

```bash
python3 python/01_connect.py --config config.json
node node/01-connect.mjs --config config.json
bash curl/01_connect.sh config.json
```

curl 版本需要 Bash、curl、Python 3（用于可靠处理 JSON），使用私有临时文件传递密钥和 Token，不把它们放到 curl 命令行。不要开启 `bash -x`。

Python/Node 成功时依次显示：

```text
1. HTTPS authenticated; token stays in memory; scopes: ...
2. device_id: ... application_version: ...
3. capabilities: ...
4. catalog ready: ... settled/discovered: ...
5. task definitions read: ...
```

核心调用代码可以直接嵌入客户后端：

```python
from aibox_client import Client, load_config  # 将 python/ 加到模块搜索路径
client = Client(load_config("config.json"))
session = client.require_scopes("device.read", "task.read")
device = client.call("device/get")
for page in client.pages("tasks/list", {"page_size": 50}):
    for task in page:
        print(task["task_id"], task["task_name"])  # 不打印整份含摄像机密码的配置
```

```javascript
import {Client, loadConfig} from './node/aibox-client.mjs';
const client = new Client(loadConfig('config.json'));
const session = await client.requireScopes('device.read', 'task.read');
const device = await client.call('device/get');
for await (const page of client.pages('tasks/list', {page_size: 50})) {
  for (const task of page) console.log(task.task_id, task.task_name);
}
```

Client 自动缓存短期 Token、提前续期，遇到 401 最多重新鉴权一次；没有 Refresh Token。实例应在客户后端复用，而不是每个请求创建一个实例。Python 参考实例按顺序使用；生产多线程场景需加锁或各自管理实例/并发预算。Node 合并并发 Token 申请，但客户仍需控制业务并发（单 Client 通常最多 2 个执行中请求）。

## 4. 创建、修改、启停任务：跑通完整闭环

先设置真实视频源；含密码时请由服务配置注入，避免 shell 历史泄漏：

```bash
export AIBOX_RTSP_URL='rtsp://camera.example/live'
```

无参数运行只显示帮助，**不创建任务**：

```bash
python3 python/02_tasks.py
node node/02-tasks.mjs
```

先只创建和修改一个新任务，不启动视频：

```bash
python3 python/02_tasks.py --create
# 或
node node/02-tasks.mjs --create
```

需要验证完整控制流程时，再显式启用运行和清理：

```bash
python3 python/02_tasks.py --create --run --delete
# 或
node node/02-tasks.mjs --create --run --delete
```

每次运行只创建 `api-demo-<随机值>` 的新任务，不选择客户现有任务测试。顺序是：

1. 确认 Scope；等 `nodes/catalog.ready=true` 且加载数量收敛。
2. 从 `device/runtime_locations.items[].value` 选择本地运行位置。
3. 读取 `netclient`、`netserver` 的真实 Schema，提取默认配置。当前插件使用 `component.formList`，不是标准 JSON Schema。
4. 构造 `netclient → netserver`，实际拉流参数是 **`rtsp_url`，不是 `url`**。
5. `graphs/validate` → `tasks/create` → `tasks/get`。
6. 深拷贝整份任务，只改名称，携带刚读取的 `expected_revision` 保存，再重新读取。
7. 指定 `--run` 时：`tasks/start` → 保存/显示 `operation_id` → 等 `succeeded` → 确认 `runtime.actual_running=true` 且 `state=running` → 查询 `media/outputs` → `tasks/stop` 并等待结果。
8. 指定 `--delete` 时：确认 `state=stopped`、`actual_running=false`，重新读取 revision，再删除**本次新建任务**。

`--run` 是短暂的启动/停止流程演示，不会留下持续推流。真实画面验收须另用 RTSP 播放器观察。示例为 RTSP 输出生成随机口令，保存在私有创建请求中；`media/outputs` 不会返回密码，不能把无凭据 URL 直接当作匿名播放保证。

每次写操作发送前，示例将完整请求、`request_id`、`idempotency_key` 保存到 `out/task-*/`。该目录可能含摄像机地址/密码，应按密钥文件保护。
失败时不盲目删除或修改其他任务：先核对任务状态与该目录，再使用原请求文件继续相同操作。

### 修改既有任务的正确代码

以下代码用于客户自己选中的任务，不由入门脚本自动执行：

```python
import copy
from aibox_client import persist_request, send_request
latest = client.call("tasks/get", {"task_id": task_id})
updated = copy.deepcopy(latest)
updated["task_name"] = "新的显示名称"
# directory 是客户创建的私有、可持久化目录；名称不能与已有请求文件重复。
request = persist_request(directory, "rename-intent-001", "tasks/save",
                          {"task": updated, "expected_revision": latest["revision"]})
saved = send_request(client, request)
```

```javascript
import {persistRequest, sendRequest} from './node/aibox-client.mjs';
const latest = await client.call('tasks/get', {task_id: taskId});
const updated = structuredClone(latest);
updated.task_name = '新的显示名称';
const request = persistRequest(directory, 'rename-intent-001', 'tasks/save',
  {task: updated, expected_revision: latest.revision});
const saved = await sendRequest(client, request);
```

**不要用 `nodes: [], edges: []` 表示“我没改节点”**，那会清空任务图。
遇到 `40901` 重新读取并由客户业务合并，不能自动用新 revision 覆盖别人的修改。
实际修改运行中的图，建议先停止并确认，再保存和启动；`tasks/apply_and_start` 也必须携带完整图和最新 revision。

### 加算法、OSD、录像或报警节点

先查询该设备 `nodes/catalog` 和每种节点的 `nodes/schema`，按返回的字段建立 `config`，再把新节点 ID 加到 `edges`。不同硬件的模型/插件可能不同，不复制 AX650N 的插件列表到 RK3588。
`task.template.json` 只示范网络输入/输出；不能保证它产生告警或录像。要产生它们，必须包含对应算法及报警/录像节点，并满足插件业务配置。可以先读取客户已调通的模板任务，再用 `tasks/clone` 创建**停止状态的新副本**，不要修改原任务试错。
`graphs/validate` 验证图结构和容量，不证明 RTSP 可达、模型已授权或硬件资源充足；仍需检查 Operation、runtime 和实际画面。

## 5. 其他能力：生成请求文件后，用任一语言调用

例如查询任务：

```bash
python3 prepare_request.py tasks/get task-get.json
# 或：node node/prepare-request.mjs tasks/get task-get.json
```

编辑生成文件，把 `REPLACE_TASK_ID` 换成真实 ID，再发送：

```bash
python3 python/call.py task-get.json
node node/call.mjs task-get.json
```

写接口由生成器提前产生唯一幂等键，并要求发送时显式 `--allow-write`；异步接口加 `--wait` 才会继续等待终态：

```bash
python3 prepare_request.py tasks/start task-start.json
# 编辑 task_id，以及从 tasks/get 获得的 revision
python3 python/call.py task-start.json --allow-write --wait
# 同一文件也可用 Node：
node node/call.mjs task-start.json --allow-write --wait
```

发送器默认只显示 code、Operation ID 和结果字段名，避免把凭据/人脸信息/下载 Ticket 打进日志；业务结果由 `Client.call()` 返回给调用代码。

| 客户流程 | 按顺序使用的 recipe / 注意事项 |
|---|---|
| 设备和网络只读状态 | `device/get` → `device/metrics` → `device/network/get` |
| 组件/插件能力 | `nodes/catalog` → `nodes/schema`；`plugins/list`、`plugins/health` |
| 复制任务 | `tasks/get` → `tasks/clone` → 读取新任务 → 按需 `tasks/start` |
| 重启任务 | 最新 `tasks/get.revision` → `tasks/restart` → Operation → runtime |
| 取消排队操作 | `operations/get` 确认 queued/cancelable → `operations/cancel` |
| 获取实时流 | `tasks/runtime` → `media/outputs`；另配置 RTSP 凭据 |
| 录像 | `records/list` → `records/get` → `records/download_ticket` → Ticket GET |
| 历史告警 | `alarms/list` → `alarms/get`；实时入口见下一节 |
| 日志 | `logs/list` → `logs/get`；不要默认逐秒全量读取 |
| 人脸 | `faces/folders`、`faces/list` → `faces/register`/`faces/update` → Operation → `faces/get` |
| 批量人脸 | `faces/batch_import`：1～8 人、Base64 合计 ≤3 MiB；终态成功后仍逐项核对成功/失败，非原子操作 |
| 智能检索 | `retrieval/status` → `retrieval/index/status` → `retrieval/query`；无模型/未就绪须明确提示 |
| 检索配置与同步 | `retrieval/settings/get` → 仅修改稳定字段 → `retrieval/settings/set`；`retrieval/sync` 只提交一次，随后查状态 |
| 在线升级（高风险，非入门步骤） | 单独审批维护窗口 → `upgrades/check` 核对 release_id/目标 → `upgrades/apply` → 持续查 `upgrades/status` → 重连核对版本 |
| 删除资源（高风险） | 先查对应资源并确认目标，再 `records/delete` / `alarms/delete` / `faces/delete`；不要用客户历史数据测试 |

人脸照片是原始 Base64，不带 `data:image/...` 前缀。Python 用 `base64.b64encode(photo_bytes).decode("ascii")`；Node 用 `Buffer.from(photoBytes).toString('base64')`。注册、更新都必须给完整必填信息和照片；不在日志中输出 Base64 或人脸个人信息。
本包不自动注册人脸、删除客户媒体、改变检索设置、升级/重启设备。

## 6. 建立 WSS 与消费事件

### 6.1 Node：一分钟内看清长连接调用步骤

```bash
export NODE_EXTRA_CA_CERTS="$(pwd)/device-ca.pem"
node node/03-events-wss.mjs --seconds 60
```

使用另一个终端运行 `02_tasks.py --create` 或 `02-tasks.mjs --create`，会看到新任务事件。WSS 程序自身不创建/启停任务。

代码顺序：HTTPS Token → HTTPS `ws/ticket` → WSS → 等 `ready` → 通过 `id` 关联请求/响应 → 订阅 → 获取快照 → 事件触发有序 `events/poll` → 演示处理 → ACK → 定期心跳 → 取消订阅并关闭。
WSS 推送可能乱序，所以示例将推送用作“有新数据”的通知，实际按服务端 poll 页推进 cursor，避免跳过还没处理的事件。

WSS 示例会处理服务端无请求 ID 的 `type=error` 帧；对安全读/轮询/ACK 的 `42901`、`50301`，在同一个总超时内最多重试 3 次并退避。权限错误、写操作、创建订阅和响应丢失不会盲目重试；持续故障明确退出。

旧设备若使用缺少 CA Key Usage 的历史证书，Python 3.13+ 的严格校验可能拒绝连接；证书 SAN 也必须包含实际访问域名/IP。应配置规范的 CA/服务端证书，不能用关闭 TLS 校验解决。本次旧证书实机对照环境为 Python 3.12.8、Node.js 22.22.1，证书链和主机名校验均开启。

这份 WSS 程序是**有限时长的连接/报文演示，不是持久化消息消费者**：默认 60 秒，断线有明确错误并退出，不会假称数据已恢复；它把控制台输出作为演示处理。不应把这一步的 ACK 直接用于客户正式业务。
长期连接需在 Token 到期前更换 Token/Ticket/连接；Ticket 一次性、旧订阅 ID 不可跨连接使用。连接关闭时未完成请求会拒绝，心跳和超时计时器会清理。

### 6.2 Python：可靠事件落库和断线后的重跑恢复

```bash
python3 python/03_events_poll.py --inbox out/customer-events.sqlite --seconds 60
# 下次继续使用同一个文件；可设置 1～3600 秒
python3 python/03_events_poll.py --inbox out/customer-events.sqlite --seconds 60
```

HTTP poll 和 WSS 使用同一个事件协议，初次/重连/游标过期都先建立订阅再取权威快照，防止快照与订阅之间漏事件。
本示例在一个 SQLite 事务中写入完整事件批次、按 `event_id` 去重，并推进 cursor，**事务提交成功后才 ACK**。初次订阅最多 100 条 replay 后继续 poll，直到补偿完；周期 poll 同时续订阅 TTL。

- `inbox` 表：已持久化的事件通知，包含 `event_id`、Topic 和 JSON 正文。
- `snapshots` 表：启动/恢复时的权威基线，不是已经自动应用每条增量事件的业务数据库。
- `meta` 表：设备 origin、Client、Topic 绑定和已提交 cursor，避免把一台设备的游标用于另一台。

实时告警的后续业务代码（Python/Node 均相同语义）：

```python
if event["topic"] == "alarm.created":
    alarm = client.call("alarms/get", {"alarm_id": event["resource"]["id"]})
    # 用 event_id 做唯一键，将 alarm 与业务处理进度一起提交到客户数据库。
    # 消费期间若告警已删除，40401 可作为已消失资源处理，不能无限重试。
```

```javascript
if (event.topic === 'alarm.created') {
  const alarm = await client.call('alarms/get', {alarm_id: event.resource.id});
  // 使用 event_id 去重，在客户事务内提交 alarm 与消费进度。
}
```

SQLite inbox 已落库，不代表已经向客户外部系统完成投递；生产消费者需实现自己的事务/Outbox、消费进度、重试死信及数据保留策略。示例不无限运行、不无限重试、不自动清理客户事件库。
40904 时旧事件窗口已不可恢复，程序明确提示并重建当前快照，不能声称补回所有历史报警。设备事件日志只保留最多 1024 条/4 MiB，长时间离线必须结合 `alarms/list` 等历史接口对账。

## 7. 下载录像，以及明确不能下载的内容

从 `records/list` 取一个真实 `record_id`：

```bash
python3 python/04_record_download.py rec_实际值 record-first-1m.part
node node/04-record-download.mjs rec_实际值 record-first-1m-node.part
```

两个示例均申请新 Ticket、只接受同源 `/record/download`，不跟随重定向，不把 Access Token 发到下载请求，不覆盖既有文件。它们只下载前 1 MiB 用于验证 Range，`.part` **不保证能单独播放**；完整下载由客户流式写盘，并验证长度、Content-Range 和续传偏移。
Ticket 失效时重新申请；不能把 Ticket URL 放日志或长期缓存。

当前公开告警模型只返回 `image_available`，**没有正式告警原图下载 Ticket 接口**。本包不会拼接盒子内部路径假装能下载报警图片。逐帧 AI 原始结果、逐节点真实 FPS、存储格式化、设备关机等也不在本版本开放边界内。项目需要时另行扩展正式协议。

## 8. 失败时如何处理，不能靠反复刷新碰运气

| 现象 | 检查与动作 |
|---|---|
| TLS/证书失败 | CA 信任、SAN/IP/域名、设备时间；不可关闭校验 |
| 非 JSON、40402 | 确认是兼容版本，真实 Path 是 `/openapi/v1/command`，不是 `/aibox/...` |
| 40101 | SDK 最多重新换 Token 一次；仍失败检查 Client 是否禁用/轮换；停止旧连接 |
| 40301 | 缺 Scope，找交付方授权，不循环重试 |
| 40901 | 重新读任务并合并修改；不强行覆盖 |
| 40902 | 同一 key 被用于不同 URI/参数；新业务创建新 key，原业务保留原 key |
| 40904 | 事件 cursor 过期；重建订阅/快照并对账，不假称无数据丢失 |
| 40905 | 资源状态冲突，不是事件游标问题；先重新查询状态 |
| 42201/42202 | 校验图、插件参数、视频源、模型授权、运行位置和资源依赖 |
| 42901/HTTP 429 | 取 `Retry-After` 与 `retry_after_ms` 更长的值，加抖动；超过调用期限就返回错误，不提前重试 |
| HTTP 202 | 仅受理；保存 `operation_id`，查到成功终态再查 runtime |
| 写请求网络超时 | 结果未知；保留原请求文件、key、request_id，对账后重试同一请求，不重跑整个新建示例 |
| Operation failed/canceled/interrupted | 明确失败，不能用 `code=0` 的外层查询响应当成功；查原 Operation |
| 断线/设备重启 | HTTPS 重建 Token；WSS 新 Ticket；用已提交 cursor 新建订阅，旧 ID 不可复用 |

SDK 只自动重试明确定义的安全读取和带原始幂等键的写操作，最多 3 次；不盲目重试创建 Client、轮换密钥、签发 Ticket、创建订阅等操作。默认单次调用预算 30 秒，异步等待 90 秒，均有上限；总时长还包含必要的鉴权和操作查询请求，不是硬实时期限。
幂等记录保留 24 小时；超过该窗口先核对资源/Operation，不能盲目重放旧写请求。并发修改、断电、磁盘满或网络不可达都不能承诺“百分之百成功”，应做到结果清晰、可定位、可重试、不误操作。

## 9. 本次验证边界

本包在 250 上执行本地隔离的 HTTPS 协议夹具、双语言运行测试和源码契约核对，不为了写示例重启/升级任何盒子。隔离测试能验证调用顺序、认证头、异常处理、幂等重试、TLS、事件事务等，但**不能替代客户型号/授权/真实摄像机/实际网络的验收**。
本次 30 项 Python/跨语言测试和 14 项 Node 测试全部通过；详见 [VALIDATION.md](VALIDATION.md)。
交付前按 [DELIVERY-CHECKLIST.md](DELIVERY-CHECKLIST.md) 填入设备版本与真实结果；不能把模拟成功标成 AX650N/RK3588 实机通过。
