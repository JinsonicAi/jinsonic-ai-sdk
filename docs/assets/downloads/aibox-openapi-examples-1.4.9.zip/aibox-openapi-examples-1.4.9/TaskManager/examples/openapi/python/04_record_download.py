"""Download at most the first 1 MiB of ONE record, using a fresh same-origin Ticket."""
import argparse
import os
from pathlib import Path
import urllib.parse
import urllib.request
from aibox_client import Client, load_config


def download_sample(client, record_id, filename):
    ticket = client.call("records/download_ticket", {"record_id": record_id})
    parsed = urllib.parse.urlsplit(ticket["url"])
    if parsed.scheme or parsed.netloc or parsed.fragment or parsed.path != "/record/download" or not urllib.parse.parse_qs(parsed.query).get("ticket"):
        raise ValueError("Unexpected download URL; refusing cross-origin credential transfer")
    request = urllib.request.Request(client.base_url + ticket["url"], headers={"Range": "bytes=0-1048575"})
    # No X-Access-Token on this request: the temporary Ticket authorizes the GET.
    with client.opener.open(request, timeout=client.timeout) as response:
        if response.code not in (200, 206):
            raise ValueError("Unexpected download HTTP status")
        if response.code == 206 and not response.headers.get("Content-Range", "").startswith("bytes 0-"):
            raise ValueError("Unexpected Content-Range")
        length = response.headers.get("Content-Length")
        if length is not None and int(length) > 1048576:
            raise ValueError("Server ignored requested range; refusing unbounded download")
        fd = os.open(filename, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        try:
            with os.fdopen(fd, "wb") as out:
                size = 0
                while True:
                    chunk = response.read(min(65536, 1048576 - size + 1))
                    if not chunk:
                        break
                    size += len(chunk)
                    if size > 1048576:
                        raise ValueError("Download exceeded range limit")
                    out.write(chunk)
                if length is not None and size != int(length):
                    raise ValueError("Incomplete download")
                out.flush()
                os.fsync(out.fileno())
        except BaseException:
            Path(filename).unlink()  # Only the partial file created by THIS call.
            raise
    return size


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("record_id", help="use a record_id returned by records/list")
    parser.add_argument("output", help="new file, never overwritten; may be a partial non-playable video")
    parser.add_argument("--config", default="config.json")
    args = parser.parse_args()
    client = Client(load_config(args.config))
    client.require_scopes("media.read")
    print("Downloaded bytes:", download_sample(client, args.record_id, args.output))


if __name__ == "__main__":
    try:
        main()
    except Exception:
        # urllib exceptions can include the URL/Ticket; never echo them.
        raise SystemExit("Download failed; check record permission, existence, trusted TLS and destination. Ticket not logged; no automatic overwrite.") from None
