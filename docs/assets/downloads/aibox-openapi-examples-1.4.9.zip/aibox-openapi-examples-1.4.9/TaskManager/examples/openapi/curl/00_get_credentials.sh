#!/usr/bin/env bash
# Password and response use private files, never curl arguments. Do not use bash -x.
set -euo pipefail
script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec python3 "$script_dir/../python/00_get_credentials.py" --transport curl "$@"
