"""AIBox OpenAPI v1 reference client. Python 3.10+, standard library only.

Server-side credentials only. No private UI routes, TLS bypass or write replay
with a newly generated key. The returned object is the envelope's `result`.
"""
import copy
import email.utils
import http.client
import json
import math
import os
from pathlib import Path
import random
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

ROOT = Path(__file__).resolve().parents[1]
CONTRACT = json.loads((ROOT / "contract.json").read_text(encoding="utf-8"))
PREFIX = "/openapi/v1/"


class ApiError(RuntimeError):
    def __init__(self, message, *, code=None, status=None, request_id="", key=""):
        # Do not include bodies, URLs, tokens, Ticket or server free-form errors.
        self.code, self.status = code, status
        self.request_id, self.idempotency_key = request_id, key
        super().__init__(f"{message}; HTTP={status} code={code} request_id={request_id} key={key}")


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def identifier(value, name):
    if not isinstance(value, str) or not 1 <= len(value) <= 128 or any(not 33 <= ord(c) <= 126 for c in value):
        raise ValueError(f"{name} must be 1..128 printable non-space ASCII characters")
    return value


def positive(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
        raise ValueError(f"{name} must be finite and positive")
    return value


def load_config(filename):
    path = Path(filename).resolve()
    config = json.loads(path.read_text(encoding="utf-8"))
    secret_file = config.pop("client_secret_file", "")
    config["client_secret"] = (path.parent / secret_file).read_text(encoding="utf-8").strip() if secret_file else os.environ.get("AIBOX_CLIENT_SECRET", "")
    if config.get("ca_file"):
        config["ca_file"] = str((path.parent / config["ca_file"]).resolve())
    return config


class Client:
    def __init__(self, config):
        self.config = config
        url = urllib.parse.urlsplit(config["base_url"])
        if url.scheme != "https" or not url.hostname or url.username or url.password or url.path not in ("", "/") or url.query or url.fragment:
            raise ValueError("base_url must be an HTTPS origin only, e.g. https://device.example:8099")
        self.base_url = config["base_url"].rstrip("/")
        self.client_id, self.secret = config["client_id"], config["client_secret"]
        if not self.client_id or not self.secret or self.client_id.startswith("REPLACE_"):
            raise ValueError("Supply the provisioned OpenAPI client_id and secret; admin/admin is NOT an API credential")
        self.timeout = positive(config.get("timeout_seconds", 30), "timeout_seconds")
        self.operation_timeout = positive(config.get("operation_timeout_seconds", 90), "operation_timeout_seconds")
        self.context = ssl.create_default_context(cafile=config.get("ca_file") or None)
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect(), urllib.request.HTTPSHandler(context=self.context))
        self.token, self.renew_at, self.scopes = "", 0, []

    def _post(self, envelope, token, timeout):
        body = json.dumps(envelope, ensure_ascii=False, allow_nan=False).encode("utf-8")
        if len(body) > CONTRACT["max_message_bytes"]:
            raise ValueError("Request exceeds 4 MiB; use smaller batches")
        headers = {"Content-Type": "application/json", "Accept": "application/json"}
        if token:
            headers["X-Access-Token"] = token
        req = urllib.request.Request(self.base_url + PREFIX + "command", data=body, headers=headers, method="POST")
        try:
            response = self.opener.open(req, timeout=timeout)
        except urllib.error.HTTPError as exc:
            response = exc
        with response:
            raw = response.read(CONTRACT["max_message_bytes"] + 1)
            status, headers = response.code, response.headers
        if len(raw) > CONTRACT["max_message_bytes"]:
            raise ApiError("Oversized response", status=status)
        try:
            data = json.loads(raw)
        except (ValueError, UnicodeError):
            raise ApiError("Non-JSON response; check device version, HTTPS entry and proxy", status=status) from None
        if not isinstance(data, dict) or type(data.get("code")) is not int:
            raise ApiError("Invalid OpenAPI response envelope", status=status)
        return status, headers, data

    def authenticate(self):
        started = time.monotonic()
        req = {"uri": PREFIX + "auth/token", "request_id": str(uuid.uuid4()), "param": {"client_id": self.client_id, "client_secret": self.secret}}
        try:
            status, _, data = self._post(req, "", self.timeout)
        except (OSError, urllib.error.URLError, http.client.HTTPException):
            raise ApiError("Token exchange transport/TLS failed; check connectivity and trusted CA", request_id=req["request_id"]) from None
        if not 200 <= status < 300 or data["code"] != 0:
            raise ApiError("Token exchange rejected; check credentials or rate-limit advice (no automatic credential retry)", code=data["code"], status=status, request_id=req["request_id"])
        result = data.get("result", {})
        if not isinstance(result, dict) or result.get("token_use") != "openapi_client" or not isinstance(result.get("access_token"), str) or not result["access_token"]:
            raise ApiError("Invalid credential domain or missing access_token")
        ttl = positive(result.get("expires_in"), "expires_in")
        self.token = result["access_token"]
        # Use server TTL + monotonic time, not the customer's wall clock.
        self.renew_at = started + max(ttl * .5, ttl - max(300, ttl * .1))
        self.scopes = result.get("scopes", [])

    @staticmethod
    def retry_delay(headers, data, attempt):
        delay = 0.3 * 2 ** attempt
        result = data.get("result", {})
        error = result.get("error", {}) if isinstance(result, dict) else {}
        milliseconds = error.get("retry_after_ms", data.get("retry_after_ms", 0))
        if isinstance(milliseconds, (int, float)) and math.isfinite(milliseconds):
            delay = max(delay, milliseconds / 1000)
        value = headers.get("Retry-After", "")
        try:
            seconds = float(value)
            if math.isfinite(seconds):
                delay = max(delay, seconds)
        except ValueError:
            try:
                delay = max(delay, email.utils.parsedate_to_datetime(value).timestamp() - time.time())
            except (TypeError, ValueError, OverflowError):
                pass
        return delay + random.uniform(0, .2)

    def call(self, route, param=None, *, idempotency_key=None, request_id=None, budget=None):
        route = route.removeprefix(PREFIX)
        if route in ("auth/token", "command", "ws") or route.startswith("clients/"):
            raise ValueError("This customer client cannot manage credentials or call transport paths")
        if not route or "?" in route or route.startswith("/") or ".." in route:
            raise ValueError("Use a Command URI, e.g. tasks/list")
        if param is not None and not isinstance(param, dict):
            raise ValueError("param must be an object")
        if route in CONTRACT["writes"] and not idempotency_key:
            raise ValueError("Persist a unique idempotency_key BEFORE the write; reuse it for retries")
        rid = identifier(request_id or str(uuid.uuid4()), "request_id")
        key = identifier(idempotency_key, "idempotency_key") if idempotency_key else ""
        request = {"uri": PREFIX + route, "request_id": rid, "param": param or {}}
        if key:
            request["idempotency_key"] = key
        # Serialize once to isolate the request from caller mutation during retry.
        request = json.loads(json.dumps(request, allow_nan=False))
        safe = route in CONTRACT["retryable_reads"] or (route in CONTRACT["writes"] and bool(key))
        if not self.token or time.monotonic() >= self.renew_at:
            self.authenticate()
        deadline = time.monotonic() + positive(budget or self.timeout, "budget")
        refreshed = False
        for attempt in range(3):
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            try:
                status, headers, data = self._post(request, self.token, remaining)
            except (OSError, urllib.error.URLError, http.client.HTTPException):
                status, headers, data = None, {}, {}
                failure = ApiError("Transport/TLS failure; write outcome may be unknown, reconcile using the SAME key", request_id=rid, key=key)
            else:
                code = data["code"]
                if 200 <= status < 300 and code == 0:
                    return data.get("result", {})
                failure = ApiError("Request rejected (403: scopes; 40901: revision; 40402: old/unsupported API)", code=code, status=status, request_id=rid, key=key)
                if code == 40101 and not refreshed:
                    self.token = ""
                    self.authenticate()
                    refreshed = True
                    continue
                error = data.get("result", {}).get("error", {}) if isinstance(data.get("result"), dict) else {}
                if code not in (42901,) and status != 429 and not (status >= 500 and error.get("retryable") is True):
                    raise failure
            if not safe or attempt == 2:
                raise failure
            delay = self.retry_delay(headers, data, attempt)
            if time.monotonic() + delay >= deadline:
                raise failure  # Never shorten Retry-After to fit our deadline.
            time.sleep(delay)
        raise ApiError("Request deadline exceeded; do not generate a new write key", request_id=rid, key=key)

    def require_scopes(self, *scopes):
        session = self.call("session/get")
        if not set(scopes).issubset(set(session.get("scopes", []))):
            raise ValueError("Ask the integrator for missing scopes: " + ", ".join(sorted(set(scopes) - set(session.get("scopes", [])))))
        return session

    def pages(self, route, param=None, *, max_pages=1000):
        query, seen = dict(param or {}), set()
        for _ in range(max_pages):
            result = self.call(route, query)
            yield result["items"]
            if not result.get("has_more"):
                return
            cursor = result.get("next_cursor")
            if not isinstance(cursor, str) or not cursor or cursor in seen:
                raise ApiError("Pagination cursor did not advance")
            seen.add(cursor)
            query["cursor"] = cursor
        raise ApiError("Pagination limit exceeded; reconcile a changing data set")

    def wait_operation(self, operation_id, timeout=None):
        deadline = time.monotonic() + positive(timeout or self.operation_timeout, "operation timeout")
        while time.monotonic() < deadline:
            op = self.call("operations/get", {"operation_id": operation_id}, budget=min(self.timeout, deadline - time.monotonic()))
            if op.get("state") in CONTRACT["terminal_states"]:
                if op["state"] != "succeeded" or op.get("code", 0) != 0:
                    raise ApiError("Operation ended unsuccessfully: " + str(op.get("state")), code=op.get("code"), request_id=op.get("request_id", ""))
                return op
            time.sleep(min(.5, max(0, deadline - time.monotonic())))
        raise ApiError("Operation deadline exceeded; query this ID later, do not resubmit: " + operation_id)


def node_defaults(schema):
    """Current plugin form metadata is NOT standard JSON Schema."""
    fields = schema.get("component", {}).get("formList")
    if not isinstance(fields, list):
        raise ValueError("Unsupported node schema layout; consult nodes/schema instead of guessing defaults")
    return {field["key"]: copy.deepcopy(field["default"]) for field in fields if isinstance(field, dict) and isinstance(field.get("key"), str) and "default" in field}


def persist_request(directory, name, route, param):
    """Customer-owned journal: no token, but config can contain camera passwords."""
    request = {"uri": PREFIX + route, "request_id": str(uuid.uuid4()), "param": param}
    if route in CONTRACT["writes"]:
        request["idempotency_key"] = str(uuid.uuid4())
    path = Path(directory) / (name + ".json")
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as out:
        json.dump(request, out, ensure_ascii=False, indent=2)
        out.flush()
        os.fsync(out.fileno())
    return request


def send_request(client, request):
    return client.call(request["uri"], request["param"], request_id=request.get("request_id"), idempotency_key=request.get("idempotency_key"))
