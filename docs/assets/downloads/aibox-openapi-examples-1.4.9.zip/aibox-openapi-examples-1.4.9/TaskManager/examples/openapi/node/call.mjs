import fs from 'node:fs';
import {parseArgs} from 'node:util';
import {Client, CONTRACT, PREFIX, loadConfig, sendRequest} from './aibox-client.mjs';
try {
  const {values, positionals} = parseArgs({allowPositionals: true, options: {config: {type: 'string', default: 'config.json'}, 'allow-write': {type: 'boolean'}, wait: {type: 'boolean'}}});
  if (positionals.length !== 1) throw Error('Usage: node node/call.mjs request.json [--allow-write] [--wait]');
  const raw = fs.readFileSync(positionals[0], 'utf8');
  if (raw.includes('REPLACE_')) throw Error('Replace sample placeholders before sending');
  const request = JSON.parse(raw);
  const route = request.uri.startsWith(PREFIX) ? request.uri.slice(PREFIX.length) : request.uri;
  if (CONTRACT.writes.includes(route) && !values['allow-write']) throw Error('This changes device data; explicitly add --allow-write');
  const client = new Client(loadConfig(values.config));
  const result = await sendRequest(client, request);
  console.log('code=0 operation_id=' + (result?.operation_id ?? ''), 'result_fields=' + Object.keys(result).join(','));
  if (values.wait && result?.operation_id) {await client.waitOperation(result.operation_id); console.log('operation succeeded');}
} catch (error) {console.error(error.message); process.exitCode = 1;}
