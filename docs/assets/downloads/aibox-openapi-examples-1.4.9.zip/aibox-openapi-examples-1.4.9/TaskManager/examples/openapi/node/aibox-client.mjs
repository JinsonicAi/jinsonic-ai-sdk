// Node.js 22+, built-ins only. Trusted server/BFF use, NEVER ship secrets to a browser.
import https from 'node:https';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomUUID} from 'node:crypto';
import {setTimeout as sleep} from 'node:timers/promises';

export const ROOT = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
export const CONTRACT = JSON.parse(fs.readFileSync(path.join(ROOT, 'contract.json'), 'utf8'));
export const PREFIX = '/openapi/v1/';

export class ApiError extends Error {
  constructor(message, {code = null, status = null, requestId = '', key = ''} = {}) {
    super(`${message}; HTTP=${status} code=${code} request_id=${requestId} key=${key}`);
    Object.assign(this, {code, status, requestId, idempotencyKey: key});
  }
}

function positive(value, name) {
  if (typeof value !== 'number' || !Number.isFinite(value) || value <= 0) throw Error(`${name} must be finite and positive`);
  return value;
}

function identifier(value, name) {
  if (typeof value !== 'string' || !/^[\x21-\x7e]{1,128}$/.test(value)) throw Error(`Invalid ${name}`);
  return value;
}

export function loadConfig(filename) {
  const config = JSON.parse(fs.readFileSync(filename, 'utf8'));
  const directory = path.dirname(path.resolve(filename));
  config.client_secret = config.client_secret_file
    ? fs.readFileSync(path.resolve(directory, config.client_secret_file), 'utf8').trim()
    : (process.env.AIBOX_CLIENT_SECRET ?? '');
  if (config.ca_file) config.ca_file = path.resolve(directory, config.ca_file);
  return config;
}

export class Client {
  constructor(config) {
    this.config = config;
    const url = new URL(config.base_url);
    if (url.protocol !== 'https:' || !url.hostname || url.username || url.password || url.pathname !== '/' || url.search || url.hash) throw Error('base_url must be an HTTPS origin only');
    this.baseUrl = url.origin;
    if (!config.client_id || config.client_id.startsWith('REPLACE_') || !config.client_secret) throw Error('Supply OpenAPI client credentials, not admin/admin');
    this.timeout = positive(config.timeout_seconds ?? 30, 'timeout_seconds') * 1000;
    this.operationTimeout = positive(config.operation_timeout_seconds ?? 90, 'operation_timeout_seconds') * 1000;
    this.ca = config.ca_file ? fs.readFileSync(config.ca_file) : undefined;
    this.token = '';
    this.renewAt = 0;
    this.authenticating = null;
  }

  async post(envelope, token, timeout) {
    const body = Buffer.from(JSON.stringify(envelope));
    if (body.length > CONTRACT.max_message_bytes) throw Error('Request exceeds 4 MiB');
    return new Promise((resolve, reject) => {
      const headers = {'Content-Type': 'application/json', 'Content-Length': body.length, Accept: 'application/json'};
      if (token) headers['X-Access-Token'] = token;
      // https.request never follows redirects. No ambient proxy or insecure flag.
      const req = https.request(this.baseUrl + PREFIX + 'command', {method: 'POST', headers, ca: this.ca}, response => {
        let size = 0;
        const chunks = [];
        response.on('data', chunk => {
          size += chunk.length;
          if (size > CONTRACT.max_message_bytes) req.destroy(new ApiError('Oversized response'));
          else chunks.push(chunk);
        });
        response.on('error', reject);
        response.on('end', () => {
          clearTimeout(timer);
          let data;
          try { data = JSON.parse(Buffer.concat(chunks).toString('utf8')); }
          catch { reject(new ApiError('Non-JSON response; check device version and HTTPS entry', {status: response.statusCode})); return; }
          if (!data || !Number.isInteger(data.code)) { reject(new ApiError('Invalid OpenAPI envelope')); return; }
          resolve({status: response.statusCode, headers: response.headers, data});
        });
      });
      const timer = setTimeout(() => req.destroy(new Error('deadline')), timeout);
      req.on('error', error => {clearTimeout(timer); reject(error);});
      req.end(body);
    });
  }

  async authenticate() {
    if (this.authenticating) return this.authenticating;
    this.authenticating = this.exchangeToken();
    try { await this.authenticating; } finally {this.authenticating = null;}
  }

  async exchangeToken() {
    const started = performance.now();
    const requestId = randomUUID();
    let response;
    try {
      response = await this.post({uri: PREFIX + 'auth/token', request_id: requestId, param: {client_id: this.config.client_id, client_secret: this.config.client_secret}}, '', this.timeout);
    } catch {
      throw new ApiError('Token exchange transport/TLS failed; check connectivity and trusted CA', {requestId});
    }
    const {status, data} = response;
    if (status < 200 || status >= 300 || data.code !== 0) throw new ApiError('Token exchange rejected; no automatic credential retry', {status, code: data.code, requestId});
    const result = data.result;
    if (result?.token_use !== 'openapi_client' || typeof result.access_token !== 'string' || !result.access_token) throw new ApiError('Wrong credential domain or missing access_token');
    const ttl = positive(result.expires_in, 'expires_in');
    this.token = result.access_token;
    this.renewAt = started + Math.max(ttl * .5, ttl - Math.max(300, ttl * .1)) * 1000;
  }

  static retryDelay(headers, data, attempt) {
    const retryMs = Number(data?.result?.error?.retry_after_ms ?? data?.retry_after_ms ?? 0);
    const header = headers['retry-after'];
    let headerMs = 0;
    if (header) headerMs = Number.isFinite(Number(header)) ? Number(header) * 1000 : Date.parse(header) - Date.now();
    return Math.max(300 * 2 ** attempt, Number.isFinite(retryMs) ? retryMs : 0, Number.isFinite(headerMs) ? headerMs : 0) + Math.random() * 200;
  }

  async call(route, param = {}, {idempotencyKey = '', requestId = randomUUID(), budget = this.timeout} = {}) {
    route = route.startsWith(PREFIX) ? route.slice(PREFIX.length) : route;
    if (['auth/token', 'command', 'ws'].includes(route) || route.startsWith('clients/')) throw Error('Credential administration is not part of the customer client');
    if (!route || route.startsWith('/') || route.includes('?') || route.includes('..')) throw Error('Use a Command URI such as tasks/list');
    if (!param || typeof param !== 'object' || Array.isArray(param)) throw Error('param must be an object');
    if (CONTRACT.writes.includes(route) && !idempotencyKey) throw Error('Persist an idempotency_key BEFORE sending the write');
    identifier(requestId, 'request_id');
    if (idempotencyKey) identifier(idempotencyKey, 'idempotency_key');
    const envelope = structuredClone({uri: PREFIX + route, param, request_id: requestId, ...(idempotencyKey ? {idempotency_key: idempotencyKey} : {})});
    if (Buffer.byteLength(JSON.stringify(envelope)) > CONTRACT.max_message_bytes) throw Error('Request exceeds 4 MiB');
    const safe = CONTRACT.retryable_reads.includes(route) || (CONTRACT.writes.includes(route) && !!idempotencyKey);
    if (!this.token || performance.now() >= this.renewAt) await this.authenticate();
    const deadline = performance.now() + positive(budget, 'budget');
    let refreshed = false;
    for (let attempt = 0; attempt < 3; attempt++) {
      const remaining = deadline - performance.now();
      if (remaining <= 0) break;
      let status = null, headers = {}, data = {}, failure;
      try {
        ({status, headers, data} = await this.post(envelope, this.token, remaining));
      } catch (error) {
        if (error instanceof ApiError) throw error;
        failure = new ApiError('Transport/TLS failure; write outcome may be unknown, reconcile with SAME key', {requestId, key: idempotencyKey});
      }
      if (!failure) {
        if (status >= 200 && status < 300 && data.code === 0) return data.result ?? {};
        failure = new ApiError('Request rejected (403: scopes; 40901: revision; 40402: unsupported API)', {status, code: data.code, requestId, key: idempotencyKey});
        if (data.code === 40101 && !refreshed) {this.token = ''; await this.authenticate(); refreshed = true; continue;}
        if (data.code !== 42901 && status !== 429 && !(status >= 500 && data.result?.error?.retryable === true)) throw failure;
      }
      if (!safe || attempt === 2) throw failure;
      const delay = Client.retryDelay(headers, data, attempt);
      if (performance.now() + delay >= deadline) throw failure;
      await sleep(delay);
    }
    throw new ApiError('Request deadline exceeded; do not generate a new write key', {requestId, key: idempotencyKey});
  }

  async requireScopes(...required) {
    const session = await this.call('session/get');
    const missing = required.filter(scope => !session.scopes?.includes(scope));
    if (missing.length) throw Error('Ask the integrator for scopes: ' + missing.join(', '));
    return session;
  }

  async *pages(route, param = {}, maxPages = 1000) {
    const query = {...param}, seen = new Set();
    for (let i = 0; i < maxPages; i++) {
      const result = await this.call(route, query);
      yield result.items;
      if (!result.has_more) return;
      if (typeof result.next_cursor !== 'string' || !result.next_cursor || seen.has(result.next_cursor)) throw new ApiError('Pagination cursor did not advance');
      seen.add(result.next_cursor);
      query.cursor = result.next_cursor;
    }
    throw new ApiError('Pagination limit exceeded');
  }

  async waitOperation(operationId, timeout = this.operationTimeout) {
    const deadline = performance.now() + positive(timeout, 'operation timeout');
    while (performance.now() < deadline) {
      const op = await this.call('operations/get', {operation_id: operationId}, {budget: Math.min(this.timeout, deadline - performance.now())});
      if (CONTRACT.terminal_states.includes(op.state)) {
        if (op.state !== 'succeeded' || (op.code ?? 0) !== 0) throw new ApiError('Operation ended unsuccessfully: ' + op.state, {code: op.code, requestId: op.request_id});
        return op;
      }
      await sleep(Math.min(500, Math.max(0, deadline - performance.now())));
    }
    throw new ApiError('Operation deadline exceeded; query this ID later: ' + operationId);
  }
}

export function nodeDefaults(schema) {
  const fields = schema?.component?.formList;
  if (!Array.isArray(fields)) throw Error('Unsupported node schema layout; do not guess defaults');
  return Object.fromEntries(fields.filter(field => typeof field.key === 'string' && Object.hasOwn(field, 'default')).map(field => [field.key, structuredClone(field.default)]));
}

export function persistRequest(directory, name, route, param) {
  const request = {uri: PREFIX + route, request_id: randomUUID(), param};
  if (CONTRACT.writes.includes(route)) request.idempotency_key = randomUUID();
  const fd = fs.openSync(path.join(directory, name + '.json'), 'wx', 0o600);
  try {fs.writeFileSync(fd, JSON.stringify(request, null, 2)); fs.fsyncSync(fd);} finally {fs.closeSync(fd);}
  return request;
}

export function sendRequest(client, request) {
  return client.call(request.uri, request.param, {requestId: request.request_id, idempotencyKey: request.idempotency_key});
}
