"""Durable, ordered HTTP event example: SQLite inbox + cursor in one transaction.

No external packages. Retained inbox is an integration boundary, NOT delivery to
the customer's external business system. Add an outbox/transaction there.
"""
import argparse
import json
import os
from pathlib import Path
import sqlite3
import time
from aibox_client import ApiError, Client, load_config

TOPICS = ["alarm.created", "alarm.deleted", "task.created", "task.updated", "task.deleted", "task.state.changed", "node.state.changed", "device.state.changed"]


class Inbox:
    def __init__(self, filename, identity):
        path = Path(filename)
        path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        if not path.exists():
            fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            os.close(fd)
        self.db = sqlite3.connect(path, timeout=3)
        self.db.execute("PRAGMA synchronous=FULL")
        self.db.executescript("""
          CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
          CREATE TABLE IF NOT EXISTS inbox (event_id TEXT PRIMARY KEY, sequence INTEGER,
              topic TEXT NOT NULL, payload TEXT NOT NULL);
          CREATE TABLE IF NOT EXISTS snapshots (kind TEXT, id TEXT, payload TEXT,
              PRIMARY KEY(kind,id));
        """)
        binding = json.dumps(identity, sort_keys=True)
        old = self.db.execute("SELECT value FROM meta WHERE key='identity'").fetchone()
        if old and old[0] != binding:
            self.db.close()
            raise ValueError("Inbox belongs to another device/client/topic set; use a separate file")
        with self.db:
            self.db.execute("INSERT OR IGNORE INTO meta VALUES ('identity', ?)", (binding,))

    def cursor(self):
        row = self.db.execute("SELECT value FROM meta WHERE key='cursor'").fetchone()
        return row[0] if row else ""

    def commit(self, events, cursor):
        if not isinstance(cursor, str) or not cursor:
            raise ValueError("Missing event cursor; refusing ACK")
        # Persist the COMPLETE batch before its next_cursor. Sequence can have gaps
        # for filtered topics, so use ordered poll pages, not sequence + 1 guesses.
        with self.db:
            for event in events:
                if not isinstance(event.get("event_id"), str) or not event["event_id"]:
                    raise ValueError("Invalid event; batch will not be acknowledged")
                self.db.execute("INSERT OR IGNORE INTO inbox VALUES (?,?,?,?)", (event["event_id"], event.get("sequence"), event["topic"], json.dumps(event, ensure_ascii=False)))
            self.db.execute("INSERT OR REPLACE INTO meta VALUES ('cursor', ?)", (cursor,))

    def snapshot(self, client):
        # Subscription is already active before this scan. Events after the
        # subscription's cursor are consumed next, closing the snapshot race.
        device = client.call("device/get")
        tasks = {item["task_id"]: item for page in client.pages("tasks/list") for item in page}
        alarms = {item["alarm_id"]: item for page in client.pages("alarms/list") for item in page}
        with self.db:
            self.db.execute("DELETE FROM snapshots")  # Local example cache ONLY.
            for kind, resources in (("device", {device["device_id"]: device}), ("task", tasks), ("alarm", alarms)):
                for resource_id, value in resources.items():
                    self.db.execute("INSERT INTO snapshots VALUES (?,?,?)", (kind, resource_id, json.dumps(value, ensure_ascii=False)))


def consume(client, inbox, seconds):
    deadline = time.monotonic() + seconds
    subscription = None
    try:
        while time.monotonic() < deadline:
            try:
                if subscription is None:
                    cursor = inbox.cursor()
                    params = {"topics": TOPICS, **({"cursor": cursor} if cursor else {})}
                    try:
                        sub = client.call("events/subscribe", params)
                    except ApiError as exc:
                        if exc.code != 40904:
                            raise
                        print("40904: event history unavailable. Rebuilding snapshots; historical events outside retention cannot be recovered.")
                        sub = client.call("events/subscribe", {"topics": TOPICS})
                    subscription = sub["subscription_id"]
                    inbox.snapshot(client)
                    inbox.commit(sub.get("replay_items", []), sub["next_cursor"])
                    client.call("events/ack", {"subscription_id": subscription, "cursor": inbox.cursor()})
                # Poll even after the initial <=100 replay_items; drain every page.
                batch = client.call("events/poll", {"subscription_id": subscription, "cursor": inbox.cursor(), "page_size": 100})
                inbox.commit(batch["items"], batch["next_cursor"])
                client.call("events/ack", {"subscription_id": subscription, "cursor": inbox.cursor()})
                if batch["items"]:
                    print("Committed event batch:", len(batch["items"]))
                if not batch.get("has_more"):
                    time.sleep(min(1, max(0, deadline - time.monotonic())))
            except ApiError as exc:
                if exc.code not in (40401, 40904):
                    raise  # No infinite retry, authorization bypass or early ACK.
                if subscription:
                    try:
                        client.call("events/unsubscribe", {"subscription_id": subscription})
                    except ApiError:
                        pass  # Stale/expired subscription may already be gone.
                subscription = None
    finally:
        if subscription:
            try:
                client.call("events/unsubscribe", {"subscription_id": subscription})
            except ApiError:
                print("Subscription cleanup not confirmed; it will expire. Cursor remains on disk.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="config.json")
    parser.add_argument("--inbox", default="out/events.sqlite")
    parser.add_argument("--seconds", type=int, default=60)
    args = parser.parse_args()
    if not 1 <= args.seconds <= 3600:
        raise ValueError("--seconds must be 1..3600; apply a retention policy for continuous production use")
    client = Client(load_config(args.config))
    client.require_scopes("device.read", "task.read", "alarm.read")
    inbox = Inbox(args.inbox, {"origin": client.base_url, "client_id": client.client_id, "topics": TOPICS})
    try:
        consume(client, inbox, args.seconds)
        print("Event inbox committed. Restart with the same file to resume; inspect new alarms with alarms/get.")
    finally:
        inbox.db.close()


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        raise SystemExit(str(exc) + "\nCursor is not advanced for an uncommitted batch; fix the error and resume with the same inbox.") from None
