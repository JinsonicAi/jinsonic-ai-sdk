# 客户调用示例验证记录

示例/协议文档版本：1.4.9；接口版本：OpenAPI v1；验证日期：2026-09-06。

## 已执行

在构建服务器 250 本机运行，Python 3.14.4、Node.js 22.22.1，标准库实现，不安装第三方依赖。
测试服务仅监听 `127.0.0.1` 的随机端口，以临时测试 CA 建立真实 HTTPS/WSS；未关闭证书校验。
服务端业务响应由隔离夹具模拟，不调用现场设备，不升级、重启或修改任何客户任务。

| 验证 | 结果 |
|---|---|
| Python 测试集（同时启动 Python、Node、curl 示例） | 35/35 通过 |
| Node 客户端与 WSS 故障处理测试集 | 21/21 通过 |
| ZIP 解压后的独立入口冒烟 | 12/12 通过：三种自助领取、三种连接、双语言任务、HTTP 事件、WSS、双语言下载 |
| 协议 URI 清单 | 65 项与中英文协议、源码注册字符串一致 |
| 节点默认配置 | 测试读取仓库真实 netclient/netserver 插件 Schema；使用 rtsp_url |
| 生产认证代码及挂接守卫 | 4/4 通过；3 项编译/运行真实 C++ SQLite 代码并启用 ASan/UBSan，1 项为协议源码挂接检查 |
| ARM64 模块 | GCC 12.2 编译协议服务、账号验证、Client 存储三个目标通过；不是完整设备包或实机验收 |

具体覆盖：

- 三种语言用网页登录账号密码领取一次 Client 凭据，生成私有目录/文件，再交给原 Client Credentials 示例获取 Token；已有输出目录不覆盖、不再次签发。
- 真实生产存储测试覆盖改密后旧凭据失效、改回旧密码不复活、账号同名同 ID 重建、事务回滚、权限收缩、锁忙、并发重复签发、容量上限、Secret 不落明文和独立旧 Client 兼容。
- Python/Node/curl 首次 HTTPS 鉴权、Scope 检查和查询；Python/Node 拒绝不可信证书。
- 双语言新建、完整修改、启停、Operation、runtime 和删除闭环；预置客户任务保持不变。
- 默认运行任务脚本不写设备；无幂等键的写请求、客户调用管理员接口被拒绝。
- HTTP 成功但业务失败、401 单次续期、403/非重试错误、429 退避、有限等待。
- 创建响应丢失后沿用原请求/幂等键，模拟服务端只产生一次效果；不同参数不能复用 key。
- 异步失败/取消/中断不判成功；分页 cursor 不前进时退出。
- SQLite 去重、批次与游标原子提交；事务失败不推进游标；跨设备身份不混用事件库。
- 205 条、序号不连续的事件补偿；先完整处理初始 replay，再处理后续分页并 ACK。
- 40904 游标过期时先新建订阅再取快照；明确告知旧事件无法从有限缓存中补回。
- 真实 TLS 下的 Node WSS Ticket、ready、请求关联、心跳、事件补偿；关闭时清理未完成请求。
- WSS 无请求 ID 的服务端错误帧立即结束等待；临时 42901/50301 仅对安全读/轮询/ACK 有限退避，最多额外尝试 3 次、共享总超时，权限拒绝/创建订阅不重试。
- 双语言生成私有请求文件、发送请求、Ticket/Range 下载；文件不覆盖，下载不携带 Access Token。

## 在源码工程复现

仅在 250 的本地源码目录执行，不能在 Mac/共享卷构建或发布验证：

```bash
cd TaskManager/examples/openapi
python3 tests/test_examples.py
node --test tests/client.test.mjs
python3 -m compileall -q python prepare_request.py tools/export_delivery.py
for item in node/*.mjs; do node --check "$item"; done
bash -n curl/01_connect.sh
bash -n curl/00_get_credentials.sh
# 或一次完成上述检查、ZIP 导出以及解压后的 12 个入口验证：
python3 tests/verify_delivery.py --output-parent ../../../.tmp
# 在工程根目录验证生产认证模块：
# python3 TaskManager/tests/test_openapi_account_auth.py -v
```

测试依赖完整源码树中两种插件的配置模板，所以客户 ZIP 不包含仓库内部测试和导出工具。
导出工具使用显式文件白名单，生成逐文件 SHA-256 清单，并重新打开 ZIP 验证内容与校验值。

## 尚不属于本次验证的结论

- **本文件只统计上述隔离测试，不充当完整实机验收报告。** 发布包的安装、实机回归及发现问题由随包的独立设备验证记录说明。
- 改密失效的实机测试须注明是否通过网页操作或专用测试账号的真实 SQLite 更新触发，不能把后者当作完整网页 UI 验收。
- 未验证客户实际 CA/域名、Scope、摄像机、算法授权、画面/OSD、长期断网与真实硬件负载。
- 未在客户设备执行人脸写入、删除媒体、修改检索设置、应用/固件升级等高风险调用。
- URI 清单覆盖和模拟通过，不代表所有可选业务、所有参数组合都已端到端验收。
- Python 3.10+ 是所用语法/API 的最低要求；本次实际运行版本为 3.14.4，未跑所有 Python/操作系统版本矩阵。
- 两块测试板的历史 CA 缺少 Key Usage、服务端 SAN 不含 LAN IP；Python 3.13+ 严格验证会拒绝这种 CA。旧证书实机对照使用 Python 3.12.8，并通过 SSH 转发匹配 localhost SAN，始终开启证书链/主机名校验。正式客户网络必须配置规范证书，不能照搬转发测试结果宣称裸 LAN IP 可直接通过 TLS。

客户上线前仍须完成 [DELIVERY-CHECKLIST.md](DELIVERY-CHECKLIST.md)。若升级固件/应用或修改协议，需重新运行测试并核对实际设备，不沿用本记录作新的验收凭据。
