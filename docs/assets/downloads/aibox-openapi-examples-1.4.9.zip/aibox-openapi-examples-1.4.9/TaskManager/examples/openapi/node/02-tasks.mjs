import fs from 'node:fs';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import {parseArgs} from 'node:util';
import {setTimeout as sleep} from 'node:timers/promises';
import {Client, ROOT, loadConfig, nodeDefaults, persistRequest, sendRequest} from './aibox-client.mjs';

async function main() {
  const {values: args} = parseArgs({options: {config: {type: 'string', default: 'config.json'}, create: {type: 'boolean'}, run: {type: 'boolean'}, delete: {type: 'boolean'}}});
  if (!args.create) {console.log('No changes. Add --create; optionally --run (start/stop) and --delete.'); return;}
  const client = new Client(loadConfig(args.config));
  await client.requireScopes('device.read', 'task.read', 'task.write', ...(args.run ? ['task.execute', 'media.read'] : []));
  const deadline = performance.now() + 30000;
  while (true) {
    const catalog = await client.call('nodes/catalog');
    if (catalog.ready && catalog.settled === catalog.discovered) break;
    if (performance.now() >= deadline) throw Error('Node catalog not ready; no task created');
    await sleep(1000);
  }
  const locations = (await client.call('device/runtime_locations')).items;
  const local = locations.find(item => item.kind === 'local')?.value;
  if (!local) throw Error('No local runtime available');
  const rtsp = process.env.AIBOX_RTSP_URL ?? '';
  if (!/^rtsps?:\/\//.test(rtsp)) throw Error('Set AIBOX_RTSP_URL reachable FROM THE BOX');
  const task = JSON.parse(fs.readFileSync(path.join(ROOT, 'task.template.json'), 'utf8'));
  task.task_id = 'api-demo-' + randomUUID();
  task.runtime_location = local;
  for (const node of task.nodes) {
    const schema = (await client.call('nodes/schema', {node_type: node.node_type})).schema;
    node.config = nodeDefaults(schema);
    const required = node.node_type === 'netclient' ? 'rtsp_url' : 'rtsp_push';
    if (!Object.hasOwn(node.config, required)) throw Error('Current schema lacks ' + required);
    if (required === 'rtsp_url') node.config.rtsp_url = rtsp;
    else Object.assign(node.config, {rtsp_push: !!args.run, user: 'openapi-demo', pass: randomUUID()});
  }
  if ((await client.call('graphs/validate', {task})).valid !== true) throw Error('Task graph invalid');
  fs.mkdirSync('out', {recursive: true, mode: 0o700});
  const journal = fs.mkdtempSync(path.join('out', 'task-'));
  console.log('New task:', task.task_id, 'Private request journal:', journal);
  async function write(name, route, param) {
    const result = await sendRequest(client, persistRequest(journal, name, route, param));
    if (result?.operation_id) {
      console.log(name, 'accepted, operation_id:', result.operation_id);
      await client.waitOperation(result.operation_id);
    }
    console.log(name, 'completed');
    return result;
  }
  await write('01-create', 'tasks/create', {task});
  let latest = await client.call('tasks/get', {task_id: task.task_id});
  const changed = structuredClone(latest); // Keep complete graph/config, never save [] just to rename.
  changed.task_name += '-已修改';
  await write('02-save', 'tasks/save', {task: changed, expected_revision: latest.revision});
  latest = await client.call('tasks/get', {task_id: task.task_id});
  if (args.run) {
    await write('03-start', 'tasks/start', {task_id: task.task_id, revision: latest.revision});
    const runtime = await client.call('tasks/runtime', {task_id: task.task_id});
    if (runtime.actual_running !== true || runtime.state !== 'running') throw Error('Runtime not running; reconcile with the journal');
    const outputs = await client.call('media/outputs', {task_id: task.task_id});
    console.log('Media output entries:', outputs.items?.length, '; RTSP credentials are in the private create request');
    await write('04-stop', 'tasks/stop', {task_id: task.task_id});
  }
  if (args.delete) {
    const runtime = await client.call('tasks/runtime', {task_id: task.task_id});
    if (runtime.actual_running !== false || runtime.state !== 'stopped') throw Error('Refusing deletion: task not confirmed stopped');
    latest = await client.call('tasks/get', {task_id: task.task_id});
    await write('05-delete', 'tasks/delete', {task_id: task.task_id, expected_revision: latest.revision});
  }
  console.log('Done. Existing tasks unchanged. Retain the private journal to reconcile uncertain outcomes.');
}
main().catch(error => {console.error(error.message, '\nNo blind cleanup: reconcile recorded task/key first.'); process.exitCode = 1;});
