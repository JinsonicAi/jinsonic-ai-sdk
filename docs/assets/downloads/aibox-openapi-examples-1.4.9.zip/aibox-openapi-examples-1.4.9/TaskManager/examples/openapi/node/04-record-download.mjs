import fs from 'node:fs';
import https from 'node:https';
import {parseArgs} from 'node:util';
import {Client, loadConfig} from './aibox-client.mjs';

async function downloadSample(client, recordId, filename) {
  const ticket = await client.call('records/download_ticket', {record_id: recordId});
  if (typeof ticket.url !== 'string' || !ticket.url.startsWith('/record/download?')) throw Error('Invalid download URL');
  const url = new URL(ticket.url, client.baseUrl);
  if (url.origin !== client.baseUrl || url.pathname !== '/record/download' || !url.searchParams.get('ticket') || url.hash) throw Error('Refusing cross-origin Ticket transfer');
  // Keep at most 1 MiB in this Range example. A full recording uses streaming.
  const data = await new Promise((resolve, reject) => {
    const req = https.get(url, {headers: {Range: 'bytes=0-1048575'}, ca: client.ca}, res => {
      if (![200, 206].includes(res.statusCode) || (res.statusCode === 206 && !res.headers['content-range']?.startsWith('bytes 0-'))) {req.destroy(Error('Unexpected range response')); return;}
      const length = res.headers['content-length'] === undefined ? null : Number(res.headers['content-length']);
      if (length !== null && (!Number.isFinite(length) || length < 0 || length > 1048576)) {req.destroy(Error('Unbounded response')); return;}
      const chunks = [];
      let size = 0;
      res.on('data', chunk => {size += chunk.length; if (size > 1048576) req.destroy(Error('Range exceeded')); else chunks.push(chunk);});
      res.on('error', reject);
      res.on('end', () => {clearTimeout(timer); if (length !== null && size !== length) reject(Error('Incomplete download')); else resolve(Buffer.concat(chunks));});
    });
    const timer = setTimeout(() => req.destroy(Error('Download timeout')), client.timeout);
    req.on('error', error => {clearTimeout(timer); reject(error);});
  });
  // Never overwrite a file and never log the Ticket URL.
  const fd = fs.openSync(filename, 'wx', 0o600);
  try {fs.writeFileSync(fd, data); fs.fsyncSync(fd);} finally {fs.closeSync(fd);}
  return data.length;
}

try {
  const {values, positionals} = parseArgs({allowPositionals: true, options: {config: {type: 'string', default: 'config.json'}}});
  if (positionals.length !== 2) throw Error('Usage: node node/04-record-download.mjs record_id new-output.part');
  const client = new Client(loadConfig(values.config));
  await client.requireScopes('media.read');
  console.log('Downloaded bytes:', await downloadSample(client, ...positionals));
} catch {
  // Transport errors may contain Ticket URLs; suppress raw exception details.
  console.error('Download failed; check record, scope, trusted TLS and destination. Ticket not logged; existing file not overwritten.');
  process.exitCode = 1;
}
