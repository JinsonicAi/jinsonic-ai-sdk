// WSS notifications wake an ordered poll; never ACK an out-of-order push.
// Durable business ingestion/recovery is demonstrated separately in Python.
import {parseArgs} from 'node:util';
import {setTimeout as sleep} from 'node:timers/promises';
import {Client, loadConfig} from './aibox-client.mjs';
import {WssChannel} from './wss-channel.mjs';

let channel;
try {
  const {values} = parseArgs({options: {config: {type: 'string', default: 'config.json'}, seconds: {type: 'string', default: '60'}}});
  const seconds = Number(values.seconds);
  if (!Number.isFinite(seconds) || seconds < 1 || seconds > 300) throw Error('--seconds must be 1..300; this is a bounded WSS onboarding example');
  const client = new Client(loadConfig(values.config));
  await client.requireScopes('task.read');
  let dirty = true, cursor = '', subscriptionId;
  channel = new WssChannel(client, {onEvent: () => {dirty = true;}});
  await channel.connect();
  console.log('WSS ready; temporary Ticket is not logged');
  const session = await channel.request('session/get');
  console.log('WSS session scopes:', session.scopes.join(', '));
  const sub = await channel.request('events/subscribe', {topics: ['task.created', 'task.updated', 'task.deleted', 'task.state.changed', 'node.state.changed']});
  subscriptionId = sub.subscription_id;
  cursor = sub.next_cursor;
  // New subscription starts NOW; take a snapshot AFTER subscribing to avoid a gap.
  let count = 0;
  for await (const items of client.pages('tasks/list')) count += items.length;
  console.log('Initial task snapshot entries:', count);
  const deadline = performance.now() + seconds * 1000;
  let lastPoll = 0;
  while (performance.now() < deadline) {
    if (!channel.opened) throw Error('Connection lost; use a new Ticket and a saved committed cursor. See Python durable consumer for recovery.');
    if (dirty || performance.now() - lastPoll > 5000) {
      dirty = false;
      let more;
      do {
        const batch = await channel.request('events/poll', {subscription_id: subscriptionId, cursor, page_size: 100});
        for (const event of batch.items) console.log('event:', event.event_id, event.topic, event.resource?.id);
        // Console is a demo sink ONLY. Production must commit business data first.
        // Do not parse the cursor or assume selected-topic sequence numbers are consecutive.
        cursor = batch.next_cursor;
        await channel.request('events/ack', {subscription_id: subscriptionId, cursor});
        more = batch.has_more;
        if (performance.now() >= deadline) break;
      } while (more);
      lastPoll = performance.now();
    }
    await sleep(100);
  }
  await channel.request('events/unsubscribe', {subscription_id: subscriptionId});
  console.log('WSS demonstration complete (not a durable business event consumer)');
} catch (error) {console.error(error.message); process.exitCode = 1;}
finally {channel?.close();}
