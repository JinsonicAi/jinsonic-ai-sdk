import {Client, loadConfig} from './aibox-client.mjs';
import {parseArgs} from 'node:util';

try {
  const {values} = parseArgs({options: {config: {type: 'string', default: 'config.json'}}});
  const client = new Client(loadConfig(values.config));
  const session = await client.requireScopes('device.read', 'task.read');
  console.log('1. HTTPS authenticated; token stays in memory; scopes:', session.scopes.join(', '));
  const device = await client.call('device/get');
  console.log('2. device_id:', device.device_id, 'application_version:', device.application_version);
  console.log('3. capabilities:', JSON.stringify(await client.call('device/capabilities')));
  const catalog = await client.call('nodes/catalog');
  console.log('4. catalog ready:', catalog.ready, 'settled/discovered:', catalog.settled, '/', catalog.discovered);
  let count = 0;
  for await (const items of client.pages('tasks/list', {page_size: 50})) count += items.length;
  console.log('5. task definitions read:', count, '(no token/camera credentials printed)');
} catch (error) {console.error(error.message); process.exitCode = 1;}
