"""One-time onboarding only. Afterwards use the unchanged Client Credentials SDK."""
import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile
import uuid
from aibox_client import ApiError, Client


def private_write(path, value):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as out:
        out.write(value)
        out.flush()
        os.fsync(out.fileno())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="bootstrap.json")
    parser.add_argument("--output-dir", required=True, help="New private directory; existing paths are never overwritten")
    parser.add_argument("--transport", choices=("python", "curl"), default="python")
    args = parser.parse_args()
    config_path = Path(args.config).resolve()
    cfg = json.loads(config_path.read_text(encoding="utf-8"))
    password = ((config_path.parent / cfg["password_file"]).read_text(encoding="utf-8").removesuffix("\n").removesuffix("\r")
                if cfg.get("password_file") else os.environ.get("AIBOX_WEB_PASSWORD", ""))
    username = cfg.get("username", "")
    if not 1 <= len(username.encode()) <= 128 or any(ord(c) < 32 or ord(c) == 127 for c in username) or not 1 <= len(password.encode()) <= 256 or "\0" in password:
        raise ValueError("Invalid username/password; use the actual web password, not its MD5")
    if cfg.get("ca_file"):
        cfg["ca_file"] = str((config_path.parent / cfg["ca_file"]).resolve())
    # Reuse only the existing HTTPS transport and CA validation; no token exchange.
    transport = Client({**cfg, "client_id": "bootstrap-transport-only", "client_secret": "unused"})
    directory = Path(args.output_dir).absolute()
    directory.mkdir(mode=0o700) # Exclusive; refuses existing directories and symlinks.
    request_id = str(uuid.uuid4())
    private_write(directory / "request-id.txt", request_id + "\n")
    param = {"username": username, "password": password, "display_name": cfg.get("display_name", "customer-integration")}
    if "scopes" in cfg:
        param["scopes"] = cfg["scopes"]
    request = {"uri": "/openapi/v1/clients/bootstrap", "request_id": request_id, "param": param}
    if args.transport == "python":
        status, _, data = transport._post(request, "", transport.timeout)
    else:
        with tempfile.TemporaryDirectory(prefix="aibox-bootstrap-") as scratch:
            body, response = Path(scratch) / "request.json", Path(scratch) / "response.json"
            private_write(body, json.dumps(request))
            command = ["curl", "--silent", "--show-error", "--noproxy", "*", "--proto", "=https",
                       "--connect-timeout", "5", "--max-time", str(transport.timeout), "--max-filesize", "4194304",
                       "-H", "Content-Type: application/json", "--data-binary", "@" + str(body),
                       "--output", str(response), "--write-out", "%{http_code}"]
            if cfg.get("ca_file"):
                command += ["--cacert", cfg["ca_file"]]
            run = subprocess.run(command + [transport.base_url + "/openapi/v1/command"], capture_output=True, text=True, timeout=transport.timeout + 5)
            if run.returncode or not response.exists() or response.stat().st_size > 4194304:
                raise ApiError("Bootstrap transport failed; do not automatically create another client", request_id=request_id)
            status, data = int(run.stdout), json.loads(response.read_text())
    if status != 200 or data.get("code") != 0:
        raise ApiError("Bootstrap rejected; 401=password, 403=scopes, 409=already issued/capacity", status=status, code=data.get("code"), request_id=request_id)
    result = data.get("result", {})
    if result.get("secret_returned_once") is not True or not re.fullmatch(r"aibc_[0-9a-f]{32}", result.get("client_id", "")) or not re.fullmatch(r"aibsk_[0-9a-f]{64}", result.get("client_secret", "")):
        raise ApiError("Invalid credential response", request_id=request_id)
    private_write(directory / "client-secret.txt", result["client_secret"] + "\n")
    private_write(directory / "config.json", json.dumps({"base_url": transport.base_url,
        "client_id": result["client_id"], "client_secret_file": "client-secret.txt",
        "ca_file": cfg.get("ca_file", ""), "timeout_seconds": transport.timeout,
        "operation_timeout_seconds": 90}, indent=2) + "\n")
    print("Client credentials saved privately. Next: 01_connect.py --config " + str(directory / "config.json"))


if __name__ == "__main__":
    try:
        main()
    except ApiError as error:
        raise SystemExit(str(error)) from None
    except Exception:
        raise SystemExit("Bootstrap failed; check input, trusted TLS and output path. Keep request-id.txt for reconciliation; no automatic retry.") from None
