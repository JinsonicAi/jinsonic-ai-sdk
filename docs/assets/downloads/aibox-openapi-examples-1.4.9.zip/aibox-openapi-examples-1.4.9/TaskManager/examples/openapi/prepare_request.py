"""Prepare one private request file; does NOT connect to or modify a device."""
import argparse
import json
import os
from pathlib import Path
import uuid

ROOT = Path(__file__).resolve().parent


def main():
    recipes = json.loads((ROOT / "recipes.json").read_text(encoding="utf-8"))
    contract = json.loads((ROOT / "contract.json").read_text(encoding="utf-8"))
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("recipe", choices=sorted(recipes))
    parser.add_argument("output", help="new JSON file; edit REPLACE_* fields before sending")
    args = parser.parse_args()
    recipe = recipes[args.recipe]
    request = {"uri": "/openapi/v1/" + args.recipe, "request_id": str(uuid.uuid4()), "param": recipe["param"]}
    if args.recipe in contract["writes"]:
        request["idempotency_key"] = str(uuid.uuid4())
    fd = os.open(args.output, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as out:
        json.dump(request, out, ensure_ascii=False, indent=2)
        out.flush()
        os.fsync(out.fileno())
    print("Prepared only; scopes:", ", ".join(recipe["scope"]) or "authenticated/no extra scope")
    print(recipe.get("note", "Replace placeholders and check actual returned resource IDs before calling."))
    print("Retry the SAME saved file for an uncertain request. A NEW intent/changed payload requires a NEW key.")


if __name__ == "__main__":
    main()
