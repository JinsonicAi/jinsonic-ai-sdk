"""Read-only onboarding: credentials -> session -> device -> catalog -> tasks."""
import argparse
import json
from aibox_client import Client, load_config


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="config.json")
    args = parser.parse_args()
    client = Client(load_config(args.config))
    session = client.require_scopes("device.read", "task.read")
    print("1. HTTPS authenticated; token stays in memory; scopes:", ", ".join(session["scopes"]))
    device = client.call("device/get")
    print("2. device_id:", device.get("device_id"), "application_version:", device.get("application_version"))
    print("3. capabilities:", json.dumps(client.call("device/capabilities"), ensure_ascii=False))
    catalog = client.call("nodes/catalog")
    print("4. catalog ready:", catalog.get("ready"), "settled/discovered:", catalog.get("settled"), "/", catalog.get("discovered"))
    count = sum(len(items) for items in client.pages("tasks/list", {"page_size": 50}))
    print("5. task definitions read:", count, "(tokens and task/camera credentials are not printed)")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        raise SystemExit(str(exc)) from None
