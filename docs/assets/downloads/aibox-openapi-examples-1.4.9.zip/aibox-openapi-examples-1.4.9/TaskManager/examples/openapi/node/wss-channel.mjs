// Finite lifetime connection helper. Event durability is in the poll example;
// reconnect always acquires a NEW one-use Ticket, never reuses a URL.
import {randomUUID} from 'node:crypto';
import path from 'node:path';
import {setTimeout as sleep} from 'node:timers/promises';
import {ApiError, CONTRACT, PREFIX} from './aibox-client.mjs';

export class WssChannel {
  constructor(client, {onEvent = () => {}, socketFactory = url => new WebSocket(url)} = {}) {
    this.client = client;
    this.onEvent = onEvent;
    this.socketFactory = socketFactory;
    this.pending = new Map();
    this.socket = null;
    this.heartbeat = null;
    this.opened = false;
  }

  async connect() {
    if (this.socket) throw Error('Close the old channel before connecting again');
    if (this.client.config.ca_file && path.resolve(process.env.NODE_EXTRA_CA_CERTS ?? '') !== path.resolve(this.client.config.ca_file)) {
      throw Error('For WSS, start Node with NODE_EXTRA_CA_CERTS set to the absolute config.ca_file path; never disable TLS checks');
    }
    const ticket = await this.client.call('ws/ticket');
    if (ticket.websocket_path !== '/openapi/v1/ws' || ticket.protocol !== CONTRACT.protocol || !/^[0-9a-f]{64}$/i.test(ticket.ticket)) throw Error('Invalid WSS ticket response');
    const url = this.client.baseUrl.replace(/^https:/, 'wss:') + ticket.websocket_path + '?ticket=' + encodeURIComponent(ticket.ticket);
    // Never print url. It contains a temporary credential.
    return new Promise((resolve, reject) => {
      const socket = this.socketFactory(url);
      this.socket = socket;
      this.readyTimer = setTimeout(() => fail(new ApiError('WSS ready timeout')), 10000);
      const fail = error => {clearTimeout(this.readyTimer); this.close(); reject(error);};
      socket.addEventListener('message', event => {
        if (typeof event.data !== 'string' || Buffer.byteLength(event.data) > CONTRACT.max_message_bytes) {fail(new ApiError('Invalid WSS message size/type')); return;}
        let message;
        try {message = JSON.parse(event.data);} catch {fail(new ApiError('Invalid WSS JSON')); return;}
        if (!message || typeof message !== 'object' || Array.isArray(message)) {fail(new ApiError('Invalid WSS envelope')); return;}
        if (message.type === 'ready' && !this.opened) {
          if (message.protocol !== CONTRACT.protocol || !message.connection_id || !Number.isFinite(message.heartbeat_interval_ms) || message.heartbeat_interval_ms < 1000 || message.heartbeat_interval_ms > 60000) {fail(new ApiError('Invalid WSS ready')); return;}
          clearTimeout(this.readyTimer);
          this.opened = true;
          this.lastReply = performance.now();
          this.heartbeat = setInterval(() => {
            if (performance.now() - this.lastReply >= 2 * message.heartbeat_interval_ms) {this.close(); return;}
            try {socket.send(JSON.stringify({type: 'ping'}));} catch {this.close();}
          }, message.heartbeat_interval_ms);
          resolve(this);
        } else if (message.type === 'response' && this.pending.has(message.id)) {
          this.lastReply = performance.now();
          const pending = this.pending.get(message.id);
          this.pending.delete(message.id);
          clearTimeout(pending.timer);
          if (message.code === 0) pending.resolve(message.result);
          else pending.reject(Object.assign(new ApiError('WSS request rejected', {code: message.code, requestId: message.request_id}), {
            retryAfterMs: message.result?.error?.retry_after_ms,
            retryable: message.result?.error?.retryable,
          }));
        } else if (message.type === 'error') {
          // The server may fail closed BEFORE dispatch (e.g. credential-store
          // contention), so this connection-level error can have no request ID.
          // Settle affected requests now instead of silently waiting for timeout.
          if (!Number.isInteger(message.code)) {fail(new ApiError('Invalid WSS error envelope')); return;}
          this.lastReply = performance.now();
          const entries = typeof message.id === 'string'
            ? [[message.id, this.pending.get(message.id)]] : [...this.pending];
          for (const [id, pending] of entries) {
            if (!pending) continue;
            this.pending.delete(id);
            clearTimeout(pending.timer);
            pending.reject(new ApiError('WSS transport request rejected', {code: message.code, requestId: id}));
          }
        } else if (message.type === 'pong') {
          this.lastReply = performance.now();
        } else if (message.type === 'event' && this.opened) {
          this.lastReply = performance.now();
          // Callback errors must not become unhandled rejections or early ACKs.
          Promise.resolve().then(() => this.onEvent(message)).catch(() => this.close());
        }
      });
      socket.addEventListener('error', () => fail(new ApiError('WSS transport/TLS error')));
      socket.addEventListener('close', event => fail(new ApiError('WSS closed; acquire a new Ticket', {code: event.code})));
    });
  }

  async request(route, param = {}) {
    const deadline = performance.now() + this.client.timeout;
    for (let attempt = 0; ; attempt++) {
      try {
        return await this.requestOnce(route, param, Math.max(1, deadline - performance.now()));
      } catch (error) {
        // No authentication bypass, no replay of writes/subscription creation,
        // and no blind retry of lost responses. Poll/ACK are safe to repeat.
        if (!this.opened || !CONTRACT.retryable_reads.includes(route) || attempt >= 3 ||
            ![42901, 50301].includes(error.code) || error.retryable === false) throw error;
        const advertised = Number(error.retryAfterMs);
        const delay = Math.max(200 * 2 ** attempt + Math.random() * 100,
          Number.isFinite(advertised) && advertised >= 0 ? advertised : 0);
        if (performance.now() + delay >= deadline) throw error;
        await sleep(delay);
      }
    }
  }

  requestOnce(route, param, timeout) {
    if (!this.opened) return Promise.reject(new ApiError('WSS is not ready'));
    // This reference channel is read/subscription-only; use journaled HTTPS writes.
    if (!CONTRACT.retryable_reads.includes(route) && !['events/subscribe', 'events/unsubscribe'].includes(route)) return Promise.reject(Error('Use the HTTPS journal for this operation'));
    if (this.pending.size >= 2) return Promise.reject(Error('WSS example allows at most 2 in-flight requests'));
    const id = randomUUID();
    const envelope = JSON.stringify({type: 'request', id, uri: PREFIX + route, request_id: id, param});
    if (Buffer.byteLength(envelope) > CONTRACT.max_message_bytes) return Promise.reject(Error('Request exceeds 4 MiB'));
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {this.pending.delete(id); reject(new ApiError('WSS response timeout', {requestId: id}));}, timeout);
      this.pending.set(id, {resolve, reject, timer});
      try {this.socket.send(envelope);} catch {clearTimeout(timer); this.pending.delete(id); reject(new ApiError('WSS send failed'));}
    });
  }

  close() {
    clearTimeout(this.readyTimer);
    clearInterval(this.heartbeat);
    this.heartbeat = null;
    this.opened = false;
    for (const entry of this.pending.values()) {clearTimeout(entry.timer); entry.reject(new ApiError('WSS closed before response'));}
    this.pending.clear();
    const socket = this.socket;
    this.socket = null;
    if (socket && socket.readyState < 2) {try {socket.close(1000, 'example finished');} catch { /* already closed */ }}
  }
}
