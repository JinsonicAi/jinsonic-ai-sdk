import fs from 'node:fs';
import path from 'node:path';
import {ROOT, persistRequest} from './aibox-client.mjs';
const recipes = JSON.parse(fs.readFileSync(path.join(ROOT, 'recipes.json'), 'utf8'));
try {
  const [route, output] = process.argv.slice(2);
  if (!recipes[route] || !output || !output.endsWith('.json')) throw Error('Usage: node node/prepare-request.mjs tasks/get request.json (new file only)');
  persistRequest(path.dirname(output), path.basename(output, '.json'), route, recipes[route].param);
  console.log('Prepared only, NOT executed; scopes:', recipes[route].scope.join(', '));
  console.log(recipes[route].note ?? 'Replace REPLACE_* fields with actual values before sending.');
  console.log('Retry this SAME file for the same intent; changed payload/new intent needs a NEW key.');
} catch (error) {console.error(error.message); process.exitCode = 1;}
