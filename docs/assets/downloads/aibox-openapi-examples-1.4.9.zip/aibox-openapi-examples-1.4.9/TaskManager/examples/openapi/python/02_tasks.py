"""Create/get/save/start/stop/delete ONLY a newly created sample task."""
import argparse
import copy
import json
import os
from pathlib import Path
import tempfile
import time
import uuid
from aibox_client import Client, ROOT, load_config, node_defaults, persist_request, send_request


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="config.json")
    parser.add_argument("--create", action="store_true", help="explicitly create and edit one NEW task")
    parser.add_argument("--run", action="store_true", help="also start, verify and stop this new task")
    parser.add_argument("--delete", action="store_true", help="delete this new task after confirming stopped")
    args = parser.parse_args()
    if not args.create:
        print("No changes. Add --create to create/save; --run for start/stop; --delete for cleanup.")
        return
    client = Client(load_config(args.config))
    scopes = ["device.read", "task.read", "task.write"] + (["task.execute", "media.read"] if args.run else [])
    client.require_scopes(*scopes)
    deadline = time.monotonic() + 30
    while True:
        catalog = client.call("nodes/catalog")
        if catalog.get("ready") and catalog.get("settled") == catalog.get("discovered"):
            break
        if time.monotonic() >= deadline:
            raise RuntimeError("Node catalog is not ready; no task created")
        time.sleep(1)
    locations = client.call("device/runtime_locations")["items"]
    local = next((item["value"] for item in locations if item.get("kind") == "local"), None)
    if not local:
        raise RuntimeError("No local runtime in device/runtime_locations")
    rtsp = os.environ.get("AIBOX_RTSP_URL", "")
    if not rtsp.startswith(("rtsp://", "rtsps://")):
        raise ValueError("Set AIBOX_RTSP_URL to a real camera/source reachable FROM THE BOX")
    task = json.loads((ROOT / "task.template.json").read_text(encoding="utf-8"))
    task["task_id"], task["runtime_location"] = "api-demo-" + uuid.uuid4().hex, local
    for node in task["nodes"]:
        schema = client.call("nodes/schema", {"node_type": node["node_type"]})["schema"]
        node["config"] = node_defaults(schema)
        required = "rtsp_url" if node["node_type"] == "netclient" else "rtsp_push"
        if required not in node["config"]:
            raise RuntimeError("Current node schema lacks " + required + "; no task created")
        if required == "rtsp_url":
            node["config"][required] = rtsp
        else:
            node["config"].update(rtsp_push=bool(args.run), user="openapi-demo", **{"pass": uuid.uuid4().hex})
    if client.call("graphs/validate", {"task": task}).get("valid") is not True:
        raise RuntimeError("Task graph validation failed")
    out = Path("out")
    out.mkdir(mode=0o700, exist_ok=True)
    journal = Path(tempfile.mkdtemp(prefix="task-", dir=out))
    print("New task:", task["task_id"], "Private request journal:", journal)

    def write(name, route, param):
        result = send_request(client, persist_request(journal, name, route, param))
        if isinstance(result, dict) and result.get("operation_id"):
            print(name, "accepted, operation_id:", result["operation_id"])
            client.wait_operation(result["operation_id"])
        print(name, "completed")
        return result

    write("01-create", "tasks/create", {"task": task})
    latest = client.call("tasks/get", {"task_id": task["task_id"]})
    changed = copy.deepcopy(latest)  # FULL replacement: retain all nodes/edges/config.
    changed["task_name"] += "-已修改"
    write("02-save", "tasks/save", {"task": changed, "expected_revision": latest["revision"]})
    latest = client.call("tasks/get", {"task_id": task["task_id"]})
    if args.run:
        write("03-start", "tasks/start", {"task_id": task["task_id"], "revision": latest["revision"]})
        runtime = client.call("tasks/runtime", {"task_id": task["task_id"]})
        if runtime.get("actual_running") is not True or runtime.get("state") != "running":
            raise RuntimeError("Start accepted but runtime not running; inspect journal and tasks/runtime")
        outputs = client.call("media/outputs", {"task_id": task["task_id"]})
        print("Media output entries:", len(outputs.get("items", [])), "; RTSP credentials are in private create request")
        # A successful runtime is NOT proof of decodable video; verify with a player.
        write("04-stop", "tasks/stop", {"task_id": task["task_id"]})
    if args.delete:
        runtime = client.call("tasks/runtime", {"task_id": task["task_id"]})
        if runtime.get("actual_running") is not False or runtime.get("state") != "stopped":
            raise RuntimeError("Refusing deletion: task is not confirmed stopped")
        latest = client.call("tasks/get", {"task_id": task["task_id"]})
        write("05-delete", "tasks/delete", {"task_id": task["task_id"], "expected_revision": latest["revision"]})
    print("Done. Existing customer tasks were not modified. Keep the journal for reconciliation; it may contain camera credentials.")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        raise SystemExit(str(exc) + "\nNo blind cleanup: reconcile the recorded task/key before retrying the same saved request.") from None
