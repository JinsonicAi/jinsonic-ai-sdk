// One-time onboarding only. Node 22+, built-ins only; business SDK is unchanged.
import fs from 'node:fs';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import {parseArgs} from 'node:util';
import {Client, ApiError} from './aibox-client.mjs';

function writePrivate(filename, value) {
  const fd = fs.openSync(filename, 'wx', 0o600);
  try {fs.writeFileSync(fd, value, 'utf8'); fs.fsyncSync(fd);} finally {fs.closeSync(fd);}
}
try {
  const {values} = parseArgs({options: {config: {type: 'string', default: 'bootstrap.json'}, 'output-dir': {type: 'string'}}});
  if (!values['output-dir']) throw Error('Missing output-dir');
  const configPath = path.resolve(values.config);
  const cfg = JSON.parse(fs.readFileSync(configPath, 'utf8'));
  const password = cfg.password_file
    ? fs.readFileSync(path.resolve(path.dirname(configPath), cfg.password_file), 'utf8').replace(/\r?\n$/, '')
    : (process.env.AIBOX_WEB_PASSWORD ?? '');
  if (typeof cfg.username !== 'string' || Buffer.byteLength(cfg.username) < 1 || Buffer.byteLength(cfg.username) > 128 || /[\x00-\x1f\x7f]/.test(cfg.username) || !password || Buffer.byteLength(password) > 256 || password.includes('\0')) throw Error('Invalid account input');
  if (cfg.ca_file) cfg.ca_file = path.resolve(path.dirname(configPath), cfg.ca_file);
  // Only reuse HTTPS transport: authenticate()/call() are intentionally not used.
  const transport = new Client({...cfg, client_id: 'bootstrap-transport-only', client_secret: 'unused'});
  const directory = path.resolve(values['output-dir']);
  fs.mkdirSync(directory, {mode: 0o700}); // Refuse to overwrite any existing output.
  const requestId = randomUUID();
  writePrivate(path.join(directory, 'request-id.txt'), requestId + '\n');
  const param = {username: cfg.username, password, display_name: cfg.display_name ?? 'customer-integration'};
  if (cfg.scopes !== undefined) param.scopes = cfg.scopes;
  const {status, data} = await transport.post({uri: '/openapi/v1/clients/bootstrap', request_id: requestId, param}, '', transport.timeout);
  if (status !== 200 || data.code !== 0) throw new ApiError('Bootstrap rejected; 401=password, 403=scopes, 409=already issued/capacity', {status, code: data.code, requestId});
  const result = data.result;
  if (result?.secret_returned_once !== true || !/^aibc_[0-9a-f]{32}$/.test(result.client_id) || !/^aibsk_[0-9a-f]{64}$/.test(result.client_secret)) throw Error('Invalid credential response');
  writePrivate(path.join(directory, 'client-secret.txt'), result.client_secret + '\n');
  writePrivate(path.join(directory, 'config.json'), JSON.stringify({base_url: transport.baseUrl, client_id: result.client_id,
    client_secret_file: 'client-secret.txt', ca_file: cfg.ca_file || '', timeout_seconds: transport.timeout / 1000,
    operation_timeout_seconds: 90}, null, 2) + '\n');
  console.log('Client credentials saved privately. Next: node/01-connect.mjs --config ' + path.join(directory, 'config.json'));
} catch (error) {
  console.error(error instanceof ApiError ? error.message : 'Bootstrap failed; check input, trusted TLS and output path. Keep request-id.txt for reconciliation; no automatic retry.');
  process.exitCode = 1;
}
