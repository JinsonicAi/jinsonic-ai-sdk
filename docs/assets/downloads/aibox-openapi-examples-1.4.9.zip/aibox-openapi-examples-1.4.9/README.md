# AIBox 第三方开放 API 客户示例 1.4.9

开始：[按步骤接入指南](TaskManager/examples/openapi/README.md)。

Python 3.10+、Node.js 22.22+ 和 curl 三种入口，无需安装 pip/npm 包。
先用设备网页登录账号密码自助领取 client_id/secret，后续沿用原 Client Credentials 流程。
进入 `TaskManager/examples/openapi`，从配置和只读连接开始，再显式执行新任务闭环。

- [中文协议](TaskManager/docs/AIBOX_OPENAPI_INTEGRATION_PROTOCOL_ZH.md)
- [English protocol](TaskManager/docs/AIBOX_OPENAPI_INTEGRATION_PROTOCOL_EN.md)
- [交付清单](TaskManager/examples/openapi/DELIVERY-CHECKLIST.md)
- [验证记录与边界](TaskManager/examples/openapi/VALIDATION.md)

此版本号是示例/文档版本，接口仍是 OpenAPI v1；不是盒子应用包版本。
本包不包含真实凭据、客户配置或数据，不会自动升级/重启设备。
隔离验证通过不替代目标设备、客户网络和业务验收。

Linux 解压后可在本目录执行 `sha256sum -c MANIFEST.sha256` 校验每个文件。
